import mongoose, { Schema, models } from "mongoose";

const doctorSchema = new Schema({
    pfp: {
        type: String
    },
    latitude: {
        type: String
    },
    longitude: {
        type: String
    },
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    dateOfBirth: {
        type: String,
        required: true
    },
    gender: {
        type: String,
        required: true
    },
    bloodGroup: {
        type: String,
        required: true
    },
    maritalStatus: {
        type: String,
        required: true
    },
    address: {
        type: String
    },
    city: {
        type: String
    },
    country: {
        type: String
    },
    role: {
        type: String,
        required: true
    },
    phone: {
        type: String
    },
    multiBirth: {
        type: String
    },


});

const Doctor = models.Doctor || mongoose.model("Doctor", doctorSchema);
export default Doctor;