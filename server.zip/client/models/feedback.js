import mongoose, { Schema, models } from "mongoose";

const feedbackSchema = new Schema({
    doctorName: {
        type: String,
        required: true
    },
    doctorPfp: {
        type: String
    },
    doctorEmail: {
        type: String,
        required: true
    },
    doctorId: {
        type: String,
        required: true
    },
    patientName: {
        type: String,
        required: true
    },
    patientPfp: {
        type: String
    },
    patientEmail: {
        type: String,
        required: true
    },
    patientId: {
        type: String,
        required: true
    },
    patientDob: {
        type: String,
        required: true
    },
    patientGender: {
        type: String,
        required: true
    },
    appointmentType: {
        type: String,
        required: true
    },
    appointmentDate: {
        type: String,
        required: true
    },
    appointmentTime: {
        type: String,
        required: true
    },
    lastUpdatedBy: {
        type: String,
        required: true
    },
    lastUpdatedAt: {
        type: String,
        required: true
    },
    createdAt: {
        type: String,
        required: true

    },
    appointmentReason: {
        type: String,
        required: true
    },
    appointmentSymptoms: {
        type: String,
        required: true
    },
    appointmentId: {
        type: String,
        required: true
    },
    feedbackTitle: {
        type: String,
        required: true

    },
    feedbackDescription: {
        type: String,
        required: true

    },
    feedbackRating: {
        type: String,
        required: true

    }
    


});

const Feedback = models.Feedback || mongoose.model("Feedback", feedbackSchema);
export default Feedback;