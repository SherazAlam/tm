import mongoose, { Schema, models } from "mongoose";

const appointmentSchema = new Schema({
    doctorName: {
        type: String,
        required: true
    },
    doctorPfp: {
        type: String
    },
    doctorEmail: {
        type: String,
        required: true
    },
    doctorId: {
        type: String,
        required: true
    },
    patientName: {
        type: String,
        required: true
    },
    patientPfp: {
        type: String
    },
    patientEmail: {
        type: String,
        required: true
    },
    patientId: {
        type: String,
        required: true
    },
    patientDob: {
        type: String,
        required: true
    },
    patientGender: {
        type: String,
        required: true
    },
    appointmentType: {
        type: String,
        required: true
    },
    appointmentDate: {
        type: String,
        required: true
    },
    appointmentTime: {
        type: String,
        required: true
    },
    lastUpdatedBy: {
        type: String,
        required: true
    },
    lastUpdatedAt: {
        type: String,
        required: true
    },
    createdAt: {
        type: String,
        required: true

    },
    appointmentReason: {
        type: String,
        required: true
    },
    appointmentSymptoms: {
        type: String,
        required: true
    },
    appointmentSession: {
        type: String,
        required: true
    },
    paymentStatus: {
        type: String,
        required: true
    },
    paymentSessionId: {
        type: String
    },
    appointmentCompleted: {
        type: Boolean
    }


});

const Appointment = models.Appointment || mongoose.model("Appointment", appointmentSchema);
export default Appointment;