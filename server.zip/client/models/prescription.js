import mongoose, { Schema, models } from "mongoose";

const prescriptionSchema = new Schema({
  patientId: { type: String, required: true },
  doctorId: { type: String, required: true },
  dateIssued: { type: Date, default: Date.now },
  medicationName: { type: String, required: true },
  dosage: { type: String, required: true },
  strength: { type: String, required: true },
  form: { type: String, required: true },
  quantity: { type: Number, required: true },
  instructions: { type: String, required: true },
  duration: { type: String, required: true },
});

const Prescription =
  models.Prescription || mongoose.model("Prescription", prescriptionSchema);
export default Prescription;
