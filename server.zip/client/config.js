// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { createUserWithEmailAndPassword, getAuth, sendEmailVerification, signInWithEmailAndPassword, signOut } from "firebase/auth";
import { doc, getFirestore, setDoc } from "firebase/firestore"
import { getStorage } from "firebase/storage";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyB6HPnImmQ8oKbA0Q1QsUufxqtz70t1Eek",
    authDomain: "telemedicine-404218.firebaseapp.com",
    projectId: "telemedicine-404218",
    storageBucket: "telemedicine-404218.appspot.com",
    messagingSenderId: "550457475951",
    appId: "1:550457475951:web:32ac0748d469cd61f89e9a"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const firestoredb = getFirestore(app)
const auth = getAuth(app);
const storage = getStorage(app);

export { firestoredb, auth, storage }
