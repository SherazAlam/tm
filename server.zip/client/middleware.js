export { default } from "next-auth/middleware"

export const config = { matcher: ["/edit_profile/:person*", "/dashboard_admin", "/appointmentrequests", "/patienthome", "/myappointments", "/doctorhome", "/alldoctors", "/prescriptions", "/history"] }