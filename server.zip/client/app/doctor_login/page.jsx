import Login from "@components/Login"
import styles from "@styles/login.module.css"
import React from 'react'


const LoginPage = () => {

    return (
        <Login title="Doctor's Login"></Login>
    )
}

export default LoginPage