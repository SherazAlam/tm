
import "@styles/globals.css"
import Provider from "@components/Provider"
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export const metadata = {
    title: "Telemedicine",
    description: "Your Health Our Priority"
}

const RootLayout = ({ children }) => {
    return (
        <html lang="en">
            <body>
                <Provider>

                    <main>
                        {children}
                    <ToastContainer/>
                    </main>
                </Provider>
            </body>
        </html>
    )
}

export default RootLayout