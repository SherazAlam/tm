"use client";
import React from "react";
import { useEffect, useState } from "react";
import Link from "next/link";

import styles from "@styles/EditProfile.module.css";
import Image from "next/image";
import Icon1 from "../../../public/icons/icon1.png";
import Icon2 from "../../../public/icons/icon2.png";
import Icon3 from "../../../public/icons/icon3.png";
import Icon4 from "../../../public/icons/icon4.png";
import Icon5 from "../../../public/icons/icon5.png";
import Icon6 from "../../../public/icons/icon6.png";
import IconBack from "../../../public/icons/goback.png";
import IconEdit from "../../../public/icons/edit.png";
import defaultAvatar from "../../../public/icons/defaultAvatar.png";
import { signOut } from "next-auth/react";
import { useSession } from "next-auth/react"



const EditProfile = ({ params }) => {
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    address: "",
    contactNo: "",
    password: "",
  });
  const { data: session } = useSession()


  useEffect(() => {
    if (session?.user) {
      console.log(session)
      setFormData((prev) => ({ ...prev, email: session?.user?.email }))
    }

  }, [session]);

  // console.log(params);

  // const getPersonDetail = async () => {
  //   try {
  //     let personData = await fetch(
  //       `http://localhost:3000/api/form/${params.editprofile}`
  //     );
  //     personData = await personData.json();
  //     if (personData) {
  //       setFormData({
  //         firstName: personData.firstName,
  //         lastName: personData.lastName,
  //         email: personData.email,
  //         address: personData.address,
  //         contactNo: personData.contactNo,
  //         city: personData.city,
  //         state: personData.state,
  //         password: personData.password,
  //         img: personData.img,
  //       });
  //     }
  //   } catch (error) {
  //     console.error("Error fetching project data:", error);
  //   }
  // };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData((prevFormData) => ({
      ...prevFormData,
      [name]: value,
    }));
  };

  const handleCancel = () => {
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      address: "",
      contactNo: "",
      city: "",
      state: "",
      password: "",
    });
  };

  // const updateProject = async (e) => {
  //   e.preventDefault();
  //   try {
  //     const {
  //       firstName,
  //       lastName,
  //       email,
  //       address,
  //       contactNo,
  //       city,
  //       state,
  //       password,
  //     } = formData;
  //     let data = await fetch(
  //       `http://localhost:3000/api/form/${params.editprofile}`,
  //       {
  //         method: "PUT",
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //         body: JSON.stringify({
  //           firstName,
  //           lastName,
  //           email,
  //           address,
  //           contactNo,
  //           city,
  //           state,
  //           password,
  //         }),
  //       }
  //     );
  //     data = await data.json();
  //     if (data.result) {
  //       setSubmitting(true);
  //       alert("Project has been updated");
  //     }
  //     setSubmitting(false);
  //   } catch (error) {
  //     console.error("Error updating project:", error);
  //   }
  // };

  return (
    <>
      <div className={`${styles.container}`}>
        {/* Sidebar */}
        <div className={`${styles.sidebar}`}>
          <div className={`${styles.icons}`}>
            <Image
              className={`${styles.icon} ${styles.selected}`}
              src={Icon1}
            />
            <Image className={`${styles.icon}`} src={Icon2} />
            <Image className={`${styles.icon}`} src={Icon3} />
            <Image className={`${styles.icon}`} src={Icon4} />
            <Image className={`${styles.icon}`} src={Icon5} />
            <Image className={`${styles.icon}`} src={Icon6} />
          </div>
        </div>
        <div className={`${styles.editFrom}`}>
          <div className={`${styles.menuSide}`}>
            <span className={`${styles.item1}`}>
              <Link href={params.entity == "doctor" ? "/doctor_login" : params.entity == "patient" ? "/patient_login" : ""}> <Image className={`${styles.backIcon}`} src={IconBack} /> </Link>
              <p>settings</p>
            </span>

            <span className={`${styles.item2}`}>
              <Image className={`${styles.editIcon}`} src={IconEdit} />
              <p className={` ${styles.mobiletext}`}>Edit Profile</p>
            </span>
            <span className={`${styles.item2}`} onClick={() => signOut()}>
              <Image className={`${styles.editIcon}`} src={Icon6} style={{ filter: "invert(1)" }} />
              <p className={` ${styles.mobiletext}`}>Logout</p>
            </span>
          </div>
          <div className={`${styles.verticalLine}`}></div>
          {/* Edit Profile Form */}
          <div className={`${styles.formSide}`}>
            <span>
              <h1>Edit {(params.entity)[0].toUpperCase() + params.entity.slice(1, (params.entity.length))}'s Profile</h1>
              <Image className={`${styles.avatar}`} src={defaultAvatar} />

            </span>
            <form className={`${styles.form}`}>
              <div>
                <span>
                  <label htmlFor="firstname">First Name</label>
                  <input
                    type="text"
                    id="firstName"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                  />
                </span>
                <span>
                  <label htmlFor="lastname">Last Name</label>
                  <input
                    type="text"
                    id="lastName"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                  />
                </span>
              </div>

              <label htmlFor="email">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
              />

              <label htmlFor="address">Address</label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
              />

              <label htmlFor="contactNo">Contact Number</label>
              <input
                type="text"
                id="contactNo"
                name="contactNo"
                value={formData.contactNo}
                onChange={handleInputChange}
              />
              <div>
                <span>
                  <label htmlFor="city">City</label>
                  <select
                    id="city"
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                  >
                    <option value="option1">Option 1</option>
                    <option value="option2">Option 2</option>
                    <option value="option3">Option 3</option>
                  </select>
                </span>
                <span>
                  <label htmlFor="state">State</label>
                  <select
                    id="state"
                    name="state"
                    value={formData.state}
                    onChange={handleInputChange}
                  >
                    <option value="option1">Option 1</option>
                    <option value="option2"> Option 2</option>
                    <option value="option3">Option 3</option>
                  </select>
                </span>
              </div>

              <label htmlFor="password">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
              />
              <span className={`${styles.buttons}`}>
                <button
                  onClick={handleCancel}
                  className={`${styles.button} ${styles.cancelBtn}`}
                >
                  Cancel
                </button>
                <button className={`${styles.button} ${styles.saveBtn}`}>
                  {submitting ? "Loading..." : "Save"}
                </button>
              </span>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditProfile;
