import { connectMongoDB } from "@lib/mongodb";
import Patient from "@models/patient";
import Doctor from "@models/doctor";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import Appointment from "@models/appointment";

export async function POST(req) {
    try {
        const data = await req.json()
        console.log("Here", data)
        // let newData = Object.assign({}, data);
        // delete newData._id;
        // delete newData.password;
        // console.log("N data", newData)
        // console.log("N data", data)

        await connectMongoDB();

        // const result = await Patient.findOne({ email: data.email });
        console.log("Here in this function");
        const result = await Appointment.create({ ...data })
        if (result) {
            console.log("appointmentBookingResult", result);
        }


        return NextResponse.json({ message: "Appointment Booked" }, { status: 201 })

        // }
        // else if (data.role == "doctor") {
        //     // const result = await Doctor.findOne(data.email);
        //     const result = await Doctor.findByIdAndUpdate(data._id, { ...newData })
        //     if (result) {
        //         console.log(result);
        //     }


        //     return NextResponse.json({ message: "User Register" }, { status: 201 })
        // }
        // else {
        //     return NextResponse.json({ message: "User is neither patient nor doctor" }, { status: 500 })

        // }
        // return NextResponse.json({ message: "okay" }, { status: 201 })

    } catch (e) {
        console.log(e);
        return NextResponse.json({ message: "An error occured" }, { status: 500 })
    }
}