import Patient from "@models/patient";
import NextAuth from "next-auth/next";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google"
import bcrypt from "bcryptjs"
import { connectMongoDB } from "@lib/mongodb";
import Doctor from "@models/doctor";

export const authOptions = {
    providers: [

        CredentialsProvider({
            name: "credentials",
            credentials: {},

            async authorize(credentials) {
                const { email, password } = credentials;
                try {
                    await connectMongoDB();
                    const patient = await Patient.findOne({ email })
                    if (patient) {
                        const passwordMatch = await bcrypt.compare(password, patient.password);
                        if (!passwordMatch) {
                            return null
                        }
                        else {
                            console.log(patient)
                            return patient
                        }
                    }
                    else {
                        await connectMongoDB();
                        const doctor = await Doctor.findOne({ email })
                        if (doctor) {
                            const passwordMatch = await bcrypt.compare(password, doctor.password);
                            if (!passwordMatch) {
                                return null
                            }
                            else {
                                console.log(doctor)
                                return doctor
                            }
                        } else {
                            return null
                        }
                    }

                }
                catch (e) {
                    console.log("Error: ", e);
                }

            }
        }),
        GoogleProvider({
            clientId: process.env.GOOGLE_CLIENT_ID ?? "",
            clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? ""
        })
    ],
    callbacks: {

        async signIn({ user, account, profile }) {
            if (account.provider === "google") {
                try {
                    await connectMongoDB();

                    const patient = await Patient.findOne({ email: user.email })
                    if (!patient) {
                        await connectMongoDB();
                        await Patient.create({ role: "patient", email: user.email, password: "google", name: "Sheraz Alam", gender: "male", maritalStatus: "Single", dateOfBirth: "23-01-2001", bloodGroup: "B+" })
                        return true
                    }
                    return true

                }
                catch (e) {
                    console.log(e);
                    return true
                }
            }
            else if (account.provider === "credentials") {
                return true
            }
            else {
                return false
            }
        },

        async session({ session, user, token }) {
            await connectMongoDB();
            console.log("d", session)
            const email = session.user.email;
            console.log("Email", email)
            const patient = await Patient.findOne({ email })
            console.log("Patient", patient)
            if (patient) {
                session.user.role = patient.role;
                session.user.id = patient._id
                session.user.gender = patient.gender
                session.user.dateOfBirth = patient.dateOfBirth
                session.user.image = patient.pfp
                return session

            }
            else {
                const doctor = await Doctor.findOne({ email })
                if (doctor) {
                    session.user.role = doctor.role;
                    session.user.id = doctor._id
                    session.user.image = doctor.pfp
                    return session
                }
            }
        }
    },
    session: {
        strategy: "jwt",
        maxAge: 24 * 60 * 60
    },
    secret: process.env.NEXTAUTH_SECRET,
    pages: {
        signIn: "/login"
    }
};
const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }