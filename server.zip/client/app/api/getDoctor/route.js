import { connectMongoDB } from "@lib/mongodb";
import Patient from "@models/patient";
import Doctor from "@models/doctor";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";

export async function POST(req) {
    try {
        const data = await req.json()
        console.log("in api", data)


        await connectMongoDB();

        const result = await Doctor.findById(data.id);
        console.log("well", result);
        if (result) {
            // console.log("Patient");
            // console.log("Doctors", result);
            // const onlyDoctor = result.filter((doctor) => {
            //     if (doctor.role == "doctor") {
            //         return true
            //     }
            // })
            // delete result.password;
            // console.log("Result", result.password);
            // console.log("onlyDoctors", onlyDoctor);
            return NextResponse.json(result, { status: 201 })
        }
        else {
            return NextResponse.json({ message: "No data found" }, { status: 404 })
        }



    } catch (e) {
        console.log(e);
        return NextResponse.json({ message: "An error occured" }, { status: 500 })
    }
}