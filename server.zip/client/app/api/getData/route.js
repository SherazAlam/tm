import { connectMongoDB } from "@lib/mongodb";
import Patient from "@models/patient";
import Doctor from "@models/doctor";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";

export async function POST(req) {
    try {
        const data = await req.json()
        console.log(data)


        await connectMongoDB();
        if (data.role == "patient") {
            const result = await Patient.findOne({ email: data.email });
            if (result) {
                console.log("Patient");
                console.log("Result", result);
                // delete result.password;
                // console.log("Result", result.password);

                return NextResponse.json({ userData: result }, { status: 201 })
            }
            else {
                return NextResponse.json({ message: "No data found" }, { status: 404 })
            }


        }
        else if (data.role == "doctor") {
            console.log("In doctor");
            const result = await Doctor.findOne({ email: data.email });
            if (result) {
                console.log("Doctor");
                console.log("Result", result);
                return NextResponse.json({ userData: result }, { status: 201 })
            }
            else {
                return NextResponse.json({ message: "No data found" }, { status: 404 })
            }


        }
        else {
            return NextResponse.json({ message: "User is neither patient nor doctor" }, { status: 500 })

        }

    } catch (e) {
        console.log(e);
        return NextResponse.json({ message: "An error occured" }, { status: 500 })
    }
}