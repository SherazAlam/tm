import { connectMongoDB } from "@lib/mongodb";
import Patient from "@models/patient";
import Doctor from "@models/doctor";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";

export async function GET() {
    try {
        // const data = await req.json()
        // console.log(data)


        await connectMongoDB();

        const result = await Doctor.find();
        console.log("well", result);
        if (result) {
            // console.log("Patient");
            console.log("Doctors", result);
            const onlyDoctor = result.filter((doctor) => {
                if (doctor.role == "doctor") {
                    return true
                }
            })
            // delete result.password;
            // console.log("Result", result.password);
            console.log("onlyDoctors", onlyDoctor);
            return NextResponse.json({ userData: onlyDoctor }, { status: 201 })
        }
        else {
            return NextResponse.json({ message: "No data found" }, { status: 404 })
        }



    } catch (e) {
        console.log(e);
        return NextResponse.json({ message: "An error occured" }, { status: 500 })
    }
}