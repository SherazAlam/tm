import { connectMongoDB } from "@lib/mongodb";
import Patient from "@models/patient";
import Doctor from "@models/doctor";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";


export async function POST(req) {
    try {
        const data = await req.json()
        console.log(data)
        const hashedPassword = await bcrypt.hash(data.password, 10);
        console.log({ ...data, password: hashedPassword });

        await connectMongoDB();
        if (data.role == "patient") {
            await Patient.create({ ...data, password: hashedPassword, phone: "", multiBirth: "", contactName: "", contactPhone: "", contactRelation: "", contactOrganization: "", contactPeriod: "", latitude: "", longitude: "", pfp: "" })

            return NextResponse.json({ message: "User Register" }, { status: 201 })

        }
        else if (data.role == "doctor") {
            await Doctor.create({ ...data, password: hashedPassword, phone: "", multiBirth: "", latitude: "", longitude: "", pfp: "" })

            return NextResponse.json({ message: "User Register" }, { status: 201 })
        }
        else {
            return NextResponse.json({ message: "User is neither patient nor doctor" }, { status: 500 })

        }

    } catch (e) {
        console.log(e);
        return NextResponse.json({ message: "An error occured" }, { status: 500 })
    }
}