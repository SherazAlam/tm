import { connectMongoDB } from "@lib/mongodb";
import Patient from "@models/patient";
import Doctor from "@models/doctor";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import Appointment from "@models/appointment";

export async function GET(req, { params }) {
    try {
        // const data = await req.json()
        console.log(params);
        console.log("Appointments Id", params.id)


        await connectMongoDB();

        const result = await Appointment.findOne( {paymentSessionId: params.id} )
        console.log("well", result);
        if (result) {
            // console.log("Patient");
            console.log("Appointment Single", result);

            // delete result.password;
            // console.log("Result", result.password);
            // console.log("onlyDoctors", result);
            return NextResponse.json({ appointment: result }, { status: 201 })
        }
        else {
            return NextResponse.json({ message: `No appointment found against that id (${params.id})` }, { status: 404 })
        }



    } catch (e) {
        console.log(e);
        return NextResponse.json({ message: "An error occured" }, { status: 500 })
    }
}