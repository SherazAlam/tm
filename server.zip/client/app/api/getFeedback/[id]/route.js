import { connectMongoDB } from "@lib/mongodb";
import Patient from "@models/patient";
import Doctor from "@models/doctor";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import Appointment from "@models/appointment";
import Feedback from "@models/feedback";

export async function GET(req, { params }) {
    try {
        // const data = await req.json()
        console.log(params);
        console.log("Doctor Id to get the feedbacks", params.id)


        await connectMongoDB();

        const result = await Feedback.find({ doctorId: params.id })
        console.log("well", result);
        if (result) {
            // console.log("Patient");
            console.log("Doctor Feedback", result);

            // delete result.password;
            // console.log("Result", result.password);
            console.log("onlyDoctors", result);
            return NextResponse.json({ feedbacks: result }, { status: 201 })
        }
        else {
            return NextResponse.json({ message: "No appointments found" }, { status: 404 })
        }



    } catch (e) {
        console.log(e);
        return NextResponse.json({ message: "An error occured" }, { status: 500 })
    }
}