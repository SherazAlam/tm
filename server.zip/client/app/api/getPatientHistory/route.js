import Appointment from "@models/appointment";

export const GET = async (request) => {
  const url = new URL(request.url);
  const searchParams = new URLSearchParams(url.search);
  const id = searchParams.get("id");
  const role = searchParams.get("type");
  console.log("Fetching", id, role);
  try {
    // Fetch appointments for the given patientId
    const query = role === "doctor" ? { doctorId: id } : { patientId: id };
    const appointments = await Appointment.find(query).exec();

    if (!appointments.length) {
      return new Response(
        JSON.stringify({ message: "No appointments found" }),
        {
          status: 404,
        }
      );
    }

    return new Response(JSON.stringify({ appointments }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
      },
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: "Internal Server Error" }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }
};
