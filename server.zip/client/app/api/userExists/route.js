import { connectMongoDB } from "@lib/mongodb";
import Doctor from "@models/doctor";
import Patient from "@models/patient";
import { NextResponse } from "next/server";


export async function POST(req) {

    const { email } = await req.json()

    try {
        await connectMongoDB();
        const patient = await Patient.findOne({ email }).select("_id");
        console.log("Patient: ", patient);
        if (patient) {
            return NextResponse.json({ patient });

        }
        else {
            await connectMongoDB();
            const doctor = await Doctor.findOne({ email }).select("_id");
            console.log("Patient: ", doctor);
            return NextResponse.json({ doctor });

        }

    } catch (e) {
        return NextResponse.json({ message: "Some Error Occured!" }, { status: 500 })
    }
}