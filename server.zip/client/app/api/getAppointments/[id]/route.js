import { connectMongoDB } from "@lib/mongodb";
import Patient from "@models/patient";
import Doctor from "@models/doctor";
import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import Appointment from "@models/appointment";

export async function GET(req, { params }) {
    try {
        // const data = await req.json()
        console.log(params);
        console.log("Appointments", params.id)


        await connectMongoDB();

        const result = await Appointment.find({ doctorId: params.id, paymentStatus: "paid", appointmentCompleted: false })
        console.log("well", result);
        if (result) {
            // console.log("Patient");
            console.log("Appointment", result);

            // delete result.password;
            // console.log("Result", result.password);
            console.log("onlyDoctors", result);
            return NextResponse.json({ appointments: result }, { status: 201 })
        }
        else {
            return NextResponse.json({ message: "No appointments found" }, { status: 404 })
        }



    } catch (e) {
        console.log(e);
        return NextResponse.json({ message: "An error occured" }, { status: 500 })
    }
}