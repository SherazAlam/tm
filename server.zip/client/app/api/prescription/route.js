import Prescription from "@models/prescription";

export const POST = async (req, res) => {
  const {
    patientId,
    doctorId,
    medicationName,
    dosage,
    strength,
    form,
    quantity,
    instructions,
    duration,
  } = await req.json();
  console.log(
    patientId,
    doctorId,
    medicationName,
    dosage,
    strength,
    form,
    quantity,
    instructions,
    duration
  );
  try {
    const result = await Prescription.create({
      date: new Date(),
      patientId,
      doctorId,
      medicationName,
      dosage,
      strength,
      form,
      quantity,
      instructions,
      duration,
    });

    return new Response(JSON.stringify("Prescription Created"), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
      },
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: "Internal Server Error" }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }
};

export const GET = async (request) => {
  const url = new URL(request.url);
  const searchParams = new URLSearchParams(url.search);
  const id = searchParams.get("id");
  const role = searchParams.get("type");
  console.log("Fetching", id, role);
  try {
    // Fetch appointments for the given patientId
    const query = role === "doctor" ? { doctorId: id } : { patientId: id };
    const prescriptions = await Prescription.find(query).exec();

    if (!prescriptions.length) {
      return new Response(
        JSON.stringify({ message: "No prescriptions found" }),
        {
          status: 404,
        }
      );
    }

    return new Response(JSON.stringify({ prescriptions }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
      },
    });
  } catch (err) {
    console.error(err);
    return new Response(JSON.stringify({ error: "Internal Server Error" }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }
};
