"use client"
import Confirmation from "@components/Confirmation"
import Personal from "@components/Personal"
import Security from "@components/Security"
import Welcome from "@components/Welcome"
import styles from "@styles/register.module.css"
import React, { useEffect, useState } from 'react'
import { useRouter } from "next/navigation"
// import { getServerSession } from "next-auth"
import { redirect } from "next/navigation";
// import { authOptions } from "@app/api/auth/[...nextauth]/route"
import { useSession } from "next-auth/react"

const RegisterPage = () => {

    const [selected, setSelected] = useState("initialData");
    const [data, setData] = useState({})
    const [error, setError] = useState("")
    const router = useRouter();
    // const session = await getServerSession(authOptions)
    // if (session) {
    //     if (session.user.role == "patient") {
    //         redirect("/edit_profile/patient")
    //     }
    //     else if (session.user.role == "doctor") {
    //         redirect("/edit_profile/doctor")
    //     }
    // }
    const { data: session, status } = useSession()
    // const session = await getServerSession(authOptions)

    useEffect(() => {
        if (session) {
            if (session.user.role == "patient") {
                redirect("/edit_profile/patient")
            }
            else if (session.user.role == "doctor") {
                redirect("/edit_profile/doctor")
            }
        }
    }, [session])
    useEffect(() => {
        console.log(data);
        console.log("s", selected);
        setError("")
    }, [data, selected])

    const handleSubmit = async () => {
        if (data.name && data.email && data.password && data.maritalStatus && data.dateOfBirth && data.gender && data.bloodGroup) {
            // alert("Account Created")

            try {
                const userCheck = await fetch("/api/userExists", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ email: data.email })
                })

                const { patient, doctor } = await userCheck.json();

                if (patient) {
                    setError("User Already Exists!")
                }
                else if (doctor) {

                    setError("User Already Exists!")
                }
                else {
                    const res = await fetch("/api/register", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({ ...data, role: data.role == "patient" ? "patient" : "doctor" })
                    })
                    if (res.ok) {
                        alert("User Successfully Registered!")
                        setData({});
                        router.push("/login")
                    }
                    else {
                        setError("Some Error occurs during registration!")
                    }
                }


            }
            catch (e) {
                console.log("Error Occured ", e)
            }

        }
        else {
            setError("Please fill all the fields")
        }
    }

    return (
        <div className={`${styles.container}`}>
            <div className={`${styles.left}`}>
                <div className={`${styles.leftContent}`}>
                    <div className={`${styles.leftContentHead}`}>
                        <img src="/images/logo.png" alt="" />
                        <h1>Telemedicine</h1>
                    </div>
                    <div className={`${styles.registrationOptions}`} >
                        <div className={`${styles.registrationOptionWrap}`} >
                            <div className={`${styles.registrationOption}`}>
                                <img src="/icons/message.svg" alt="" />
                            </div>
                            <p style={{ textDecoration: `${selected == "initialData" ? "underline" : ""}` }}>Initial Data</p>
                        </div>
                        <div className={`${styles.registrationOptionWrap}`} >
                            <div className={`${styles.registrationOption}`}>

                                <img src="/icons/lock.svg" alt="" />

                            </div>
                            <p style={{ textDecoration: `${selected == "security" ? "underline" : ""}` }}>Security</p>
                        </div>
                        <div className={`${styles.registrationOptionWrap}`}>
                            <div className={styles.registrationOption}>
                                <img src="/icons/person.svg" alt="" />
                            </div>
                            <p style={{ textDecoration: `${selected == "personalInfo" ? "underline" : ""}` }}>Personal Information</p>
                        </div>
                        <div className={`${styles.registrationOptionWrap}`}>
                            <div className={styles.registrationOption}>
                                <img src="/icons/check.svg" alt="" />
                            </div>
                            <p style={{ textDecoration: `${selected == "confirmation" ? "underline" : ""}` }} >Confirmation</p>
                        </div>
                    </div>
                </div>
            </div>
            {
                selected == "initialData" ? <Welcome setSelected={setSelected} data={data} setData={setData} setError={setError}></Welcome> :
                    selected == "security" ? <Security setSelected={setSelected} data={data} setData={setData} setError={setError}></Security> :
                        selected == "personalInfo" ? <Personal setSelected={setSelected} data={data} setData={setData} setError={setError}></Personal> :
                            selected == "confirmation" ? <Confirmation setSelected={setSelected} data={data} setData={setData} handleSubmit={handleSubmit} setError={setError}></Confirmation> : ""
            }
            {error ?
                <div style={{ position: "absolute", right: "20px", top: "20px", padding: "5px 20px", border: "1px solid black", backgroundColor: "maroon" }}>
                    <p style={{ color: "white" }}>{error}</p>
                </div>
                :
                null}




        </div >
    )
}

export default RegisterPage