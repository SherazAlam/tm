import { authOptions } from '@app/api/auth/[...nextauth]/route';
import Accordion from '@components/Accordion'
import { getServerSession } from 'next-auth';
import React from 'react'


const GetPrescriptions = async (id, type) => {
    const resp = await fetch(`${process.env.NEXTAUTH_URL}/api/prescription?id=${id}&type=${type}`, {
        cache: "no-store",
    });
    const data = await resp.json();
    return data;
};

export default async function page() {
    const session = await getServerSession(authOptions);
    const Data = await GetPrescriptions(session.user.id, session.user.role);
    console.log('dataaaaa ', Data)

    return (
        <Accordion prescriptions={Data?.prescriptions} />
    )
}
