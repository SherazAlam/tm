"use client"

import React, { useEffect } from 'react'
import "@styles/patientHome.css"
import { redirect } from "next/navigation";
import { useSession } from 'next-auth/react'

const PatientHomePage = () => {
const { data: session, status } = useSession()
    useEffect(()=>{
        if (session.user.role == "patient"){
            redirect("/setting")

        }
        else if (session.user.role == "doctor"){
            redirect("/setting")
        }
    },[])

    return (

        <div className="patientHomeContainer">
            <img src="/images/patientHome.png" alt="" />
        </div>

    )
}

export default PatientHomePage