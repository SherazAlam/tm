import EditProfile from '@components/EditProfile'
import React from 'react'

const PatientSettingPage = () => {
    return (
        <EditProfile></EditProfile>
    )
}

export default PatientSettingPage