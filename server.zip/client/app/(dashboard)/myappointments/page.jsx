import React from 'react'
import "@styles/appointmentrequest.css"
import PatientDetails from '@components/PatientDetails'
import { getServerSession } from 'next-auth';
import { authOptions } from '@app/api/auth/[...nextauth]/route';
import PatientRequests from '@components/PatientRequests';
import DoctorRequested from '@components/DoctorRequested';

const getAllPatientRequests = async () => {
    const currentPatient = await getServerSession(authOptions);
    console.log("cc", currentPatient);
    const response = await fetch(`${process.env.NEXTAUTH_URL}/api/getMyAppointments/${currentPatient.user.id}`, {
        cache: "no-store"
    });
    const myAllAppointments = await response.json();
    return myAllAppointments
}

const MyAppointment = async () => {
    const myAllAppointments = await getAllPatientRequests();
    console.log("my all appointments", myAllAppointments);
    return (
        <div className="appointmentRequestContainer">
            <DoctorRequested appointmentRequests={myAllAppointments} ></DoctorRequested>
        </div>
    )
}

export default MyAppointment