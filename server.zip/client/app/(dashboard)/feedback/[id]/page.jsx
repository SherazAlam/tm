"use client"
import React, { useEffect, useState } from 'react'
import { Icon } from '@iconify/react'
import "@styles/feedback.scss"
import { toast } from 'react-toastify'
import { useRouter } from 'next/navigation'

const FeedbackPage = ({ params }) => {
    const [noOfStars, setNoOfStars] = useState(1);
    const [feedback, setFeedback] = useState({});
    const [appointmentDetails, setAppointmentDetails] = useState({})
    const router = useRouter();
    const handleFeedbackChange = (e) => {
        setFeedback(prev=>({...prev, [e.target.name]: e.target.value}))
    }

    const getAppointment = async () => {
        const response = await fetch(`/api/getAppointment/${params.id}`, {
            cache: "no-store"
        });
        const {appointment} = await response.json();
        setAppointmentDetails(appointment)
        console.log("Well", appointment);
    }

    useEffect(()=>{
getAppointment();
    },[])

    // const handleFeedbackSubmit = ()=>{

    // }
    const handleFeedbackSubmit = async () => {
        // e.preventDefault();
  if (feedback.title && feedback.description && feedback.stars){

  
     
        // console.log("Obj", {
        //     appointmentType: e.target.elements.appointmentType.value,
        //     appointmentDate: e.target.elements.date.value,
        //     appointmentTime: e.target.elements.time.value,
        //     appointmentSymptoms: e.target.elements.appointmentSymtoms.value,
        //     appointmentReason: e.target.elements.appointmentReason.value,
        //     createdAt: String(Date.now()),
        //     doctorName: doctorData.name,
        //     doctorEmail: doctorData.email,
        //     doctorId: doctorData._id,
        //     patientName: user.name,
        //     patientEmail: user.email,
        //     patientId: user.id,
        //     patientDob: user.dateOfBirth,
        //     patientGender: user.gender,
        //     lastUpdatedBy: user.role,
        //     lastUpdatedAt: String(Date.now()),
        //     appointmentReason: "flu",
        //     appointmentSymptoms: "fly cough"
        // });
        try {
            console.log("Inside Submit Feedback");
            const res = await fetch(`/api/postFeedback`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    appointmentType: appointmentDetails.appointmentType,
                    appointmentDate: appointmentDetails.appointmentDate,
                    appointmentTime: appointmentDetails.appointmentTime,
                    appointmentSymptoms: appointmentDetails.appointmentSymptoms,
                    appointmentReason: appointmentDetails.appointmentReason,
                    createdAt: String(Date.now()),
                    doctorName: appointmentDetails.doctorName,
                    doctorEmail: appointmentDetails.doctorEmail,
                    doctorId: appointmentDetails.doctorId,
                    patientName: appointmentDetails.patientName,
                    patientEmail: appointmentDetails.patientEmail,
                    patientId: appointmentDetails.patientId,
                    patientDob: appointmentDetails.patientDob,
                    patientGender: appointmentDetails.patientGender,
                    lastUpdatedBy: appointmentDetails.lastUpdatedBy,
                    lastUpdatedAt: String(Date.now()),
                    patientPfp: appointmentDetails.patientPfp,
                    doctorPfp:appointmentDetails.doctorPfp,
                    appointmentId: params.id,
                    feedbackTitle: feedback.title,
                    feedbackDescription: feedback.description,
                    feedbackRating: feedback.stars 

                })
            })
            if (res.ok) {
                const fetchedData = await res.json();
                console.log("Let's see", fetchedData)
                // redirect("/successpage")

                // setuserData(fetchedData.userData)

                console.log("yesss");
                toast.success("Feedback Successfully Submitted!")
                // const result = await axios.post("http://localhost:8080/sendmessage", {
                //     doctorName: doctorData.name,
                //     doctorNumber: doctorData.phone,
                //     patientName: user.name
                // })
                // if (result) {
                //     console.log("sms result", result.data);
                // }
                // router.replace("/alldoctors")
                router.push("/patienthome")




            }
            else {
                toast.error("Some Error occurs during feedback submission");
            }
        }
        catch (e) {
            toast.error("Some Error occurs during feedback submission");

            console.log(e);
        }
    }
    else{
toast.error("Please fill all fields and select rating (stars)")
    }
        // console.log(e.target.element);
    }

    useEffect(()=>{
        console.log("Feedback", feedback);
    })

    return (
        <div className='feedbackContainer'>
            <div className="starsOuterContainer">

                <h1>How many stars will you give?</h1>
                <div className="starContainer" style={{ display: "flex" }}>
                    {[1, 1, 1, 1, 1].map((data, index) => (

                        <div className='star' onClick={() => {setNoOfStars(index + 1);

                            setFeedback(prev=>({...prev, stars: index + 1}))

                        }} key={index}>

                            <Icon icon={noOfStars > index ? "mdi:star" : "mdi:star-outline"} width={35} height={35} style={{ color: "#fff" }} />
                        </div>
                        // :

                        // <div className='star'>

                        // <Icon icon="mdi:star" />
                        // </div>
                    ))
                    }
                </div>
                <div className='ratingDescription'>
                    <h3>Least Likely</h3>
                    <h3>Most Likely</h3>
                </div>
            </div>
            <div className="ratingTitleContainer">
                <label htmlFor="">Title</label>
                <input type="text" name="title" id="" placeholder='Enter Title' onChange={handleFeedbackChange} />
            </div>
            <div className="ratingDescriptionContainer">
                <label htmlFor="">Description</label>

                <textarea name="description" id="" placeholder='Write Your Feedback Here!' onChange={handleFeedbackChange} ></textarea>
            </div>
            
            <button onClick={handleFeedbackSubmit} style={{padding :"6px 15px", backgroundColor: "#494993",color: "white", outline: "none", border: "none", borderRadius: "3px"}}>Submit</button>
        </div>
    )
}

export default FeedbackPage