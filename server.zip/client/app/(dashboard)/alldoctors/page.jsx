"use client"
import React, { useEffect, useState } from 'react'
import "@styles/alldoctors.css"
import Link from 'next/link';
import AllDoctorsList from '@components/AllDoctorsList';



const AllDoctors = () => {
    const [allDoctors, setAllDoctors] = useState({ useData: [] })
    // const allDoctors = await getAllDoctors();
    // console.log("hehe", allDoctors);
    const getAllDoctors = async () => {
        console.log("hehehe", process.env.NEXTAUTH_URL);
        const response = await fetch(`/api/getDoctors`, {
            cache: "no-store"
        });
        const allDoctors = await response.json();
        console.log("all", allDoctors);
        setAllDoctors(allDoctors)
        // return allDoctors
    }
    useEffect(() => {
        console.log("hshshsh");
        getAllDoctors();
    }, [])

    return (
        <div className="allDoctorsContainer">
            <AllDoctorsList allDoctors={allDoctors}></AllDoctorsList>

        </div>
    )
}

export default AllDoctors;