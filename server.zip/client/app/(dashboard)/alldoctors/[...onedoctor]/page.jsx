import React from 'react'
import "@styles/bookDoctor.css"
import "@styles/doctordetails.scss"
import "@styles/reviews.scss"
import Link from 'next/link';
import { getServerSession } from "next-auth";
import { authOptions } from '@app/api/auth/[...nextauth]/route';
import { redirect } from 'next/navigation'
import BookingForm from '@components/BookingForm';
import GoogleMaps from '@components/GoogleMaps';

import DisplayStars from '@components/DisplayStars';

const getDoctor = async (id) => {

    try {
        console.log("hellooooo", process.env.NEXTAUTH_URL);
        const res = await fetch(`${process.env.NEXTAUTH_URL}/api/getDoctor`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ id: id })
        })
        if (res.ok) {
            const fetchedData = await res.json();
            console.log("Let's see", await fetchedData)

            // setUserData(fetchedData.userData)
            return fetchedData;

        }
        else {
            // setError("Some Error occurs during registration!")
        }
    }
    catch (e) {
        console.log(e);
    }

}

const getFeedback = async(id) =>{
    try{

    
    const response = await fetch(`${process.env.NEXTAUTH_URL}/api/getFeedback/${id}`, {
        cache: "no-store"
    });
    const {feedbacks} = await response.json();
    return(feedbacks);
}
catch(e){
console.log("Error Fetching Doctor's Feedback", e);
}

}

const BookDoctor = async ({ params }) => {
    console.log("params", params);
    const doctorData = await getDoctor(params.onedoctor[1]);
    const feedbackData = await getFeedback(params.onedoctor[1]);
    console.log("Bruh", doctorData);
    const data = await getServerSession(authOptions);

    console.log("well letssss", data);



    return (
        <div className='singleDoctorOuterContainer'>
            
            {doctorData ?
            params.onedoctor[0] == "book" ?
                <div className="bookDoctorContainer">
                    <BookingForm doctorData={doctorData} userData={data}></BookingForm>
                </div>
                :
                params.onedoctor[0] == "details" ?
                    <div className="detailsContainer">
                        <h1>Doctor's Profile</h1>
                        <div className="basicInfo" style={{ marginBottom: "20px" }}>
                            <div className="profilePic">
                                <img src={doctorData.pfp ? doctorData.pfp : "/images/boy.jpg"} alt="" srcset="" />
                            </div>
                            <div className="info">
                                <p>{doctorData.name}</p>
                                <p>{doctorData.email}</p>
                                <p>{doctorData.phone}</p>
                                <p>{doctorData.gender}</p>
                                <div className="btns">

                                    <Link href={"/alldoctors"}> <button>Back</button></Link>
                                    <Link href={`/alldoctors/book/${params.onedoctor[1]}`}> <button>Book</button></Link>
                                </div>

                            </div>
                        </div>
                        {/* {JSON.stringify(feedbackData)} */}
                        
                        <div className='ReviewsContainer'>
                            <h1>Reviews</h1>
                            {feedbackData.map((feedbackData, index)=>(
                            
                            <div className="review" key={index}>
                                <img src={feedbackData.patientPfp} alt="" />
                            <div className="feedbackDetails">
                                <div className="reviewsMetaData">
<DisplayStars stars={feedbackData.feedbackRating}></DisplayStars>
<p>{feedbackData.patientName}</p>
                                </div>
                                <div className='feedbackDetail'>
                                    <h3>{feedbackData.feedbackTitle}</h3>
                                    <p>{feedbackData.feedbackDescription}</p>
                                </div>
                            </div>
                            </div>
                        ))}
                        </div>
                        {doctorData.latitude && doctorData.longitude ?
                            <><h1>Location</h1>
                                <GoogleMaps latitude={Number(doctorData.latitude)} setLatitude={async () => { "use server" }} longitude={Number(doctorData.longitude)} setlongitude={async () => { "use server" }}></GoogleMaps>
                            </>
                            :

                            ""}
                    </div>
                    :
                    <h1>Not Found</h1>
                    :
                    <>
                    <div style={{display: "flex", justifyContent: "center", flexDirection: "column", alignItems: "center", height: "100%"}}>
                        <h3>Some Error Occured. Please refresh the application.</h3>
                    <Link href={"/patienthome"}><button style={{padding :"6px 15px", backgroundColor: "#494993",color: "white", outline: "none", border: "none", borderRadius: "3px"}}>Refresh</button></Link>
                    </div>
                    </>
            }

        </div>
    )
}

export default BookDoctor