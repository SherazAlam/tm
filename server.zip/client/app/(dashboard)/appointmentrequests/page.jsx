import React from 'react'
import "@styles/appointmentrequest.css"
import PatientDetails from '@components/PatientDetails'
import { getServerSession } from 'next-auth';
import { authOptions } from '@app/api/auth/[...nextauth]/route';
import PatientRequests from '@components/PatientRequests';

const getAllPatientRequests = async () => {
    const currentDoctor = await getServerSession(authOptions);
    console.log("cc", currentDoctor);
    const response = await fetch(`${process.env.NEXTAUTH_URL}/api/getAppointments/${currentDoctor.user.id}`, {
        cache: "no-store"
    });
    const allDoctors = await response.json();
    return allDoctors
}

const AppointmentRequests = async () => {
    const appointmentRequests = await getAllPatientRequests();
    console.log("all requests", appointmentRequests);
    return (
        <div className="appointmentRequestContainer">
            <PatientRequests appointmentRequests={appointmentRequests} ></PatientRequests>
        </div>
    )
}

export default AppointmentRequests