"use client"
import Sidebar from '@components/Sidebar';
import React, { useEffect } from 'react'
import "@styles/patientsidebar.css"
import { useSession } from 'next-auth/react';

const PatientDashboardLayout = ({ children }) => {
    const { data: session, status } = useSession()
    useEffect(() => {
        console.log("Session", session);
    }, [session])
    return (
        <>
            {session == null ?
                <div style={{ height: "100vh", display: "flex", justifyContent: "center", alignItems: "center" }}>
                    <div className='loader'></div>
                </div>

                :
                <div className='patientDashboardLayout'>
                    <Sidebar></Sidebar>
                    <div className="patientDashboardChildrenContainer">
                        {children}

                    </div>
                </div>
            }
        </>
    )
}

export default PatientDashboardLayout;