import { authOptions } from "@app/api/auth/[...nextauth]/route";
import "@styles/historyTable.css"
import { getServerSession } from "next-auth";


const GetPaitentHistroy = async (id, type) => {
    const resp = await fetch(`${process.env.NEXTAUTH_URL}/api/getPatientHistory?id=${id}&type=${type}`, {
        cache: "no-store",
    });
    const data = await resp.json();
    return data;
};

export default async function page() {
    const session = await getServerSession(authOptions);
    const Data = await GetPaitentHistroy(session.user.id, session.user.role);
    console.log('dataaaaa ', Data)

    return (

        <div class="container">
            <h1>Appointment History</h1>
            <table class="appointment-history" style={{overflowY: "auto"}}>
                <thead>
                    <tr>
                        <th>Doctor</th>
                        <th>Patient</th>
                        <th>Appointment Date</th>
                        <th>Appointment Time</th>
                        <th>Type</th>
                        <th>Reason</th>
                        <th>Symptoms</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {Array.isArray(Data.appointments) && Data?.appointments.map((val, ind) => <tr>
                        <td>
                            <div class="profile-info">
                                <img src={val.doctorPfp} alt="Muhammad Sheraz Alam" class="profile-img" />
                                {val.doctorName}
                            </div>
                        </td>
                        <td>
                            <div class="profile-info">
                                <img src={val.patientPfp} alt="Durefishan Saleem" class="profile-img" />
                                {val.patientName}
                            </div>
                        </td>
                        <td>{val.appointmentDate}</td>
                        <td>{val.appointmentTime}</td>
                        <td>{val.appointmentType}</td>
                        <td>{val.appointmentReason}</td>
                        <td>{val.appointmentSymptoms}</td>
                        <td>{val.appointmentCompleted ? 'Completed' : 'Not Completed'}</td>
                    </tr>)}
                </tbody>
            </table>
        </div>
    )
}
