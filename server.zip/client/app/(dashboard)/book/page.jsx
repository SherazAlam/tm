import React from 'react'
import "@styles/bookDoctor.css"

const BookDoctor = () => {
    return (
        <div className="bookDoctorContainer">
            <div className="bookDoctor">
                <div className="bookDate">
                    <h4>Select Date</h4>
                    <input type="date" />
                </div>
                <div className="bookTime">
                    <h4>Select Time</h4>
                    <input type="time" />
                </div>
                <div className="bookButtons">
                    <button className='cancelBtn'>Cancel</button>
                    <button className='confirmBtn'>Confirm</button>
                </div>
            </div>
        </div>
    )
}

export default BookDoctor