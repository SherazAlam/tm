"use client"
import { useRouter } from 'next/navigation'
import React from 'react'

const VideoCallPage = () => {
    const router = useRouter();

    return (
        <div>Video Call</div>
    )
}

export default VideoCallPage