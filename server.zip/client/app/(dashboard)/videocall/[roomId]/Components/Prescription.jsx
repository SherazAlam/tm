import React, { useState } from "react";
import { Modal, Input, Select, InputNumber, Button } from "antd";
import "@styles/Prescription.css";

const Prescription = ({ appointment }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form, setForm] = useState({
    patientId: appointment.patientId,
    doctorId: appointment.doctorId,
    dateIssued: null,
    medicationName: "",
    dosage: "",
    strength: "",
    form: "",
    quantity: null,
    instructions: "",
    duration: "",
  });

  console.log(appointment);

  const PrescriptionData = async (formData) => {
    try {
      const res = await fetch("/api/prescription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        console.log("Prescription data submitted successfully.");
      } else {
        console.error("Failed to submit prescription data.");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSelectChange = (value) => {
    setForm({
      ...form,
      form: value,
    });
  };

  const handleNumberChange = (value) => {
    setForm({
      ...form,
      quantity: value,
    });
  };

  const handleOk = () => {
    PrescriptionData(form);
    setForm({
      patientId: "",
      doctorId: "",
      dateIssued: null,
      medicationName: "",
      dosage: "",
      strength: "",
      form: "",
      quantity: null,
      instructions: "",
      duration: "",
    });
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setForm({
      patientId: "",
      doctorId: "",
      dateIssued: null,
      medicationName: "",
      dosage: "",
      strength: "",
      form: "",
      quantity: null,
      instructions: "",
      duration: "",
    });
    setIsModalOpen(false);
  };

  const showModal = () => {
    setIsModalOpen(true);
  };

  return (
    <div>
      <div className="Button">
        <Button type="primary" onClick={showModal}>
          Add Prescriptions
        </Button>
      </div>
      <Modal
        title="Prescriptions Details"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <div className="form-container">
          <div className="form-div">
            <div className="form-innerdiv">
              <label>Patient ID:</label>
              <Input
                name="patientId"
                value={appointment.patientId}
                onChange={handleChange}
                readOnly
                required
              />
            </div>
            <div className="form-innerdiv">
              <label>Doctor ID:</label>
              <Input
                name="doctorId"
                value={appointment.doctorId}
                onChange={handleChange}
                required
                readOnly
              />
            </div>
          </div>
          <div className="form-innerdiv">
            <label>Medication Name:</label>
            <Input
              name="medicationName"
              value={form.medicationName}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-div">
            <div className="form-innerdiv">
              <label>Dosage:</label>
              <Input
                name="dosage"
                value={form.dosage}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-innerdiv">
              <label>Strength:</label>
              <Input
                name="strength"
                value={form.strength}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="form-div">
            <div style={{ width: "50%" }}>
              <label>Quantity:</label>
              <InputNumber
                value={form.quantity}
                onChange={handleNumberChange}
                required
              />
            </div>
            <div
              style={{
                width: "50%",
                display: "flex",
                gap: "20px",
              }}
            >
              <div style={{ width: "50%" }}>
                <label>Form:</label>
                <Select
                  value={form.form}
                  onChange={handleSelectChange}
                  required
                >
                  <Select.Option value="tablet">Tablet</Select.Option>
                  <Select.Option value="capsule">Capsule</Select.Option>
                  <Select.Option value="syrup">Syrup</Select.Option>
                </Select>
              </div>
              <div style={{ width: "50%" }}>
                <label>Duration:</label>
                <Input
                  name="duration"
                  value={form.duration}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
          </div>
          <label>Instructions:</label>
          <Input.TextArea
            name="instructions"
            value={form.instructions}
            onChange={handleChange}
            required
          />
        </div>
      </Modal>
    </div>
  );
};

export default Prescription;
