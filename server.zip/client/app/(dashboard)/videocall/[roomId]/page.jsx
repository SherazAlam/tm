"use client";
import React, { useEffect, useState } from "react";
import { ZegoUIKitPrebuilt } from "@zegocloud/zego-uikit-prebuilt";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import "@styles/videoCalling.scss";
import axios from "axios";
import Prescription from "./Components/Prescription";

const VideoCallOneToOne = ({ params }) => {
  const router = useRouter();
  const [show, setshow] = useState(false);
  const { data: session } = useSession();
  const [appointment, setappointment] = useState(null);

  useEffect(() => {
    const getAppointment = async () => {
      const response = await fetch(`/api/getAppointment/${params.roomId}`, {
        cache: "no-store",
      });
      const { appointment } = await response.json();
      setappointment(appointment);
    };

    getAppointment();
  }, []);

  useEffect(() => {
    console.log("Calling Mounted", session.user.role);
    if (session.user.role == "doctor") {
      // updateSession("started")
    } else {
    }
  }, []);

  const updateSession = async (status) => {
    try {
      console.log("Updated called");
      const res = await fetch("/api/updateSession", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ appointmentSession: status, id: params.roomId }),
      });
      if (status == "started"){
          // const result = await axios.post("http://localhost:8080/sendmessage", {
          //     doctorName: session?.user?.name,
          //     // doctorNumber: doctorData.phone,
          //     // patientName: user.name
          // })
          // if (result) {
          //     console.log("sms result", result.data);
          // }
      }
      if (res.ok) {
        // const fetchedData = await res.json();
        // console.log("Let's see", await fetchedData)
        // alert("Data Updated Successfully!");
        // setUserData(fetchedData.userData)
        // toast.success("Appointment Session Updated Successfully!")
      } else {
        // toast.error("Some Error occurs during rescheduling!")
      }
    } catch (e) {
      console.log(e);
    }
  };

  const mymeeting = async (element) => {
    // if (!hehe) {
    const appID = 946219318;
    const serverSecret = "8e0b853d79deae0bcbfe949b73ca46a4";
    const kitToken = ZegoUIKitPrebuilt.generateKitTokenForTest(
      appID,
      serverSecret,
      params?.roomId,
      Date.now().toString(),
      session && session.user && session.user.name ? session.user.name : ""
    );
    const zc = ZegoUIKitPrebuilt.create(kitToken);
    console.log("Calling initiated!");

    zc.joinRoom({
      container: element,
      scenario: {
        mode: ZegoUIKitPrebuilt.OneONoneCall,
      },
      onJoinRoom: async () => {
        // Add your custom logic
        console.log("start");
        if (session.user.role == "doctor") {
          await updateSession("started");
          setshow(true);
        }
      },
      onLeaveRoom: async () => {
        console.log("on Leave");
        if (session.user.role == "doctor") {
          await updateSession("notStarted");
          setshow(false);
        }
        session &&
        session.user &&
        session.user.role &&
        session.user.role == "patient"
          ? (location.href =
              window.location.protocol +
              "//" +
              window.location.host +
              "/feedback/" +
              params.roomId)
          : (location.href =
              window.location.protocol +
              "//" +
              window.location.host +
              "/appointmentrequests");
      },
      preJoinViewConfig: {
        title: `Join Telemedicine's Session`,
      },
      onUserAvatarSetter: (userList) => {
        userList.forEach((user) => {
          if (user.userName == session.user.name) {
            user.setUserAvatar(session.user.image);
          }
        });
        console.log("ddddd", userList);
      },
      showLeaveRoomConfirmDialog: false,
      showLeavingView: false,
      showScreenSharingButton: false,
    });
    // }
  };
  return (
    <>
      {show && <Prescription appointment={appointment} />}
      <div className="mainContainer" ref={mymeeting} />
    </>
  );
};

export default VideoCallOneToOne;
