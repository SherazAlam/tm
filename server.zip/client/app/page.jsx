import Homepage from "@components/Homepage"


const Home = () => {
    return (
        <Homepage></Homepage>
    )
}

export default Home