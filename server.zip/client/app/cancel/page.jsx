"use client"
import React, { useEffect } from 'react'
import "@styles/patientsidebar.css";
import { useRouter } from 'next/navigation';


const Cancel = () => {
    const router = useRouter();
   
  return (
    <div>
    <div
      style={{
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
        <h3 style={{ marginTop: "10px" }}>
        Ops you cancelled the payment! Redirecting to dahboard...
      </h3>
      <button onClick={()=>{router.push("/patienthome")}} style={{padding :"6px 15px", backgroundColor: "#494993",color: "white", outline: "none", border: "none", borderRadius: "3px"}}>Go to Dashboard</button>
      
    </div>
  </div>
  )
}

export default Cancel