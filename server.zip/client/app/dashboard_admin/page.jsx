"use client"
import React, { useState } from 'react'
import "@styles/admin_dashboard.css"
import Image from 'next/image'
import { signOut } from "next-auth/react";

const Admin = () => {
    const [active, setActive] = useState("newDoctors");
    return (
        <div className="container">
            <div className="left">
                <div className="logoContainer">
                    <Image className='logo' src="/images/Logo.png" width={100} height={100}></Image>
                    <h4>Telemedicine</h4>
                </div>
                <div className="menuContainer">
                    <div className={`menuItem ${active == "newDoctors" ? "active" : ""}`} onClick={() => setActive("newDoctors")}>
                        New Doctors
                    </div>
                    <div className={`menuItem ${active == "newPatient" ? "active" : ""}`} onClick={() => setActive("newPatients")}>
                        New Patients
                    </div>
                    <div className="menuItem">
                        All Doctors
                    </div>
                    <div className="menuItem">
                        All Patients
                    </div>
                </div>
            </div>

            {active == "newDoctors" ?

                <div className="right">
                    <div className="header">
                        <span className='greetings'>
                            Hello Admin!
                        </span>
                        <span className='logout' onClick={() => signOut()}>Logout</span>
                    </div>
                    <div className="rightContent">
                        <h2>New Doctors</h2>
                        <div className="rightContentItem even">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Dr. Ashraf</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                        <div className="rightContentItem">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Dr. Ashraf</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                        <div className="rightContentItem even">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Dr. Ashraf</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                        <div className="rightContentItem">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Dr. Ashraf</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                        <div className="rightContentItem even">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Dr. Ashraf</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                    </div>





                </div>

                :

                <div className="right">
                    <div className="header">
                        <span className='greetings'>
                            Hello Admin!
                        </span>
                        <span className='logout'>Logout</span>
                    </div>
                    <div className="rightContent">
                        <h2>New Patients</h2>
                        <div className="rightContentItem even">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Sheraz</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                        <div className="rightContentItem">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Aleeza</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                        <div className="rightContentItem even">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Muqadus</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                        <div className="rightContentItem">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Haris</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                        <div className="rightContentItem even">
                            <div className="rightContentItemLeft">
                                <Image className='doctorAvatar' src={"/images/boy.jpg"} width={50} height={50}></Image>
                                <p className='doctorName'>Abdul Rehman</p>
                            </div>
                            <div className="rightContentItemRight">
                                <button className='actionBtn details'>Details</button>
                                <button className='actionBtn approve'>Approve</button>
                                <button className='actionBtn reject'>Reject</button>

                            </div>
                        </div>
                    </div>





                </div>}


        </div>
    )
}

export default Admin