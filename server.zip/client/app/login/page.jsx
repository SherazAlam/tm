// "use client"
// import { getServerSession } from "next-auth"
// import { redirect } from "next/navigation";
// import { authOptions } from "@app/api/auth/[...nextauth]/route"
import Login from "@components/Login"
import styles from "@styles/login.module.css"
import React from 'react'


const LoginPage = () => {

    // const session = await getServerSession(authOptions)
    // if (session) {
    //     if (session.user.role == "patient") {
    //         redirect("/edit_profile/patient")
    //     }
    //     else if (session.user.role == "doctor") {
    //         redirect("/edit_profile/doctor")
    //     }
    // }


    return (
        <Login></Login>
    )
}

export default LoginPage