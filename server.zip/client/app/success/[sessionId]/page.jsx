"use client";
import React, { useEffect, useState } from "react";
import "@styles/patientsidebar.css";
import axios from "axios";
import { toast } from "react-toastify";
import { useRouter } from "next/navigation";

const Success = ({ params }) => {
  const [test, setTest] = useState(false);
  const router = useRouter();
  const checkPaymentStatus = async () => {
    console.log("Called Success");
    try {
      const sessionDetails = await axios.post(
        "http://localhost:8080/get-session-info",
        { sessionId: params.sessionId }
      );
      console.log("Session Details", sessionDetails);
      if (!sessionDetails.data.message) {
        if (sessionDetails.data.sessionDetails.payment_status == "paid") {
          console.log("paid");
          const response = await fetch(
            `/api/getAppointmentByPaymentId/${params.sessionId}`,
            {
              cache: "no-store",
            }
          );
          const { appointment } = await response.json();
          console.log("Got the appointment", appointment);
          const res = await fetch("/api/updateAppointment", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              paymentStatus: "paid",
              id: appointment._id,
            }),
          });
          if (res.ok) {
            // const fetchedData = await res.json();
            // console.log("Let's see", await fetchedData)
            // alert("Data Updated Successfully!");
            // setUserData(fetchedData.userData)
            // toast.success("Appointment Session Updated Successfully!")
            // toast.success("Payment is successfully verified!", {toastId: "success"});
            setTest(true);
            router.push("/myappointments");
          } else {
            console.log("SessionDetails", sessionDetails);
            toast.error("Payment was not successful", {toastId: "failure"});
            router.push("/patienthome");
            setTimeout(() => {
              router.push("/patienthome");
            }, 2000);
          }
        } else {
          toast.error("Some Error Occured during payment verification", {toastId: "failure"});
          setTimeout(() => {
            router.push("/patienthome");
          }, 2000);
        }
      }
    } catch (e) {
      console.log("Error", e);
    }
  };
  useEffect(() => {
    checkPaymentStatus();
  }, []);
  return (
    <div>
      <div
        style={{
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "column",
        }}
      >
        {!true ? 
        <>
        <div className="loader"></div>
        <h3 style={{ marginTop: "10px" }}>
          Please wait we are verifying your payment!
        </h3>
        </>
      :
      
        <h3 style={{ marginTop: "10px" }}>
          Payment Verified!
        </h3>
      }
        
      </div>
    </div>
  );
};

export default Success;
