"use client"
import axios from 'axios'
import Link from 'next/link'
import React, { useEffect, useState } from 'react'

const AllDoctorsList = ({ allDoctors }) => {
    const [currentUserLatitute, setCurrentUserLatitude] = useState("")
    const [currentUserLongitude, setCurrentUserLongitude] = useState("")
    const [nearDoctor, setNearDoctor] = useState("")
    const [searchQuery, setSearchQuery] = useState("")
    const handleNearFilter = (e) => {
        console.log(e.target.checked);
        if (e.target.checked) {
            navigator.geolocation.getCurrentPosition((position) => {
                console.log(position.coords);
                setCurrentUserLatitude(position.coords.latitude)
                setCurrentUserLongitude(position.coords.longitude)
            })
        }
        else {
            setCurrentUserLatitude("");
            setCurrentUserLongitude("");
            setNearDoctor("")
        }
    }
    const calculateDistance = async () => {
        let allPromisesArray = []
        let options = {
            method: 'GET',
            url: 'https://distance-calculation-api-by-pizza-api.p.rapidapi.com/distance',
            params: {
                lat1: '33.646226',
                lon1: '73.055746',
                lat2: currentUserLatitute,
                lon2: currentUserLongitude,
                metric: 'km'
            },
            headers: {
                'X-RapidAPI-Key': '4255d377c3msh0bf410067c91449p178f77jsnd80b369ddd57',
                'X-RapidAPI-Host': 'distance-calculation-api-by-pizza-api.p.rapidapi.com'
            }
        };
        allDoctors.userData.map((doctor) => {
            options.params.lat1 = doctor.latitude;
            options.params.lon1 = doctor.longitude;
            try {
                const response = axios.request(options);
                allPromisesArray.push(response)
            } catch (error) {
                console.error(error);
            }
        })

        const result = await Promise.all(allPromisesArray)
        let tempDoc = allDoctors;
        let doctorsWithLocation = result.map((res, index) => ({ ...tempDoc.userData[index], distance: Math.round(res.data.distance) }))
        setNearDoctor(doctorsWithLocation)
        console.log("well Temp", doctorsWithLocation);

    }
    useEffect(() => {
        if (currentUserLatitute && currentUserLongitude) {

            calculateDistance();
        }
    }, [currentUserLatitute])

    return (
        <>
            <h2 className='allDoctors'>All Doctors</h2>
            <div className="searchSection">
                <div className="inputSearch">
                    <input type="text" placeholder='Search any doctor here' onChange={(e) => setSearchQuery(e.target.value)} />
                    {/* <button>Search</button> */}
                </div>
                <div className="searchFilters">
                    <label htmlFor="nearMe">Near Me</label>
                    <input type="checkbox" name="Nearme" id="nearMe" onChange={handleNearFilter} />
                </div>

            </div>
            <div className="doctorsSection">
                <div className="allDoctorsTable">
                    {
                        nearDoctor ? nearDoctor.map((doctor, index) => (
                            doctor.distance < 25 ?
                                searchQuery ? doctor.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
                                    <div className="SingleDoctor" key={index}>
                                        <p>Dr. {doctor.name} <span style={{ color: "#494993" }}>({doctor.distance}KM away)</span></p>
                                        <div className="singleDoctorsActionButtons">
                                            <Link href={`/alldoctors/details/${doctor._id}`}><button>Details</button></Link>
                                            <Link href={`/alldoctors/book/${doctor._id}`}> <button>Book</button></Link>
                                        </div>
                                    </div>
                                    :
                                    <div className="SingleDoctor">
                                        <p>Dr. {doctor.name} <span style={{ color: "#494993" }}>({doctor.distance}KM away)</span></p>
                                        <div className="singleDoctorsActionButtons">
                                            <Link href={`/alldoctors/details/${doctor._id}`}><button>Details</button></Link>
                                            <Link href={`/alldoctors/book/${doctor._id}`}> <button>Book</button></Link>
                                        </div>
                                    </div>
                                :
                                ""
                        ))
                            :

                            allDoctors.userData && allDoctors.userData.map((doctor, index) => (
                                searchQuery ? doctor.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
                                    <div className="SingleDoctor" key={index}>
                                        <p>Dr. {doctor.name}</p>
                                        <div className="singleDoctorsActionButtons">
                                            <Link href={`/alldoctors/details/${doctor._id}`}><button>Details</button></Link>
                                            <Link href={`/alldoctors/book/${doctor._id}`}> <button>Book</button></Link>
                                        </div>
                                    </div>
                                    :
                                    <div className="SingleDoctor" key={index}>
                                        <p>Dr. {doctor.name}</p>
                                        <div className="singleDoctorsActionButtons">
                                            <Link href={`/alldoctors/details/${doctor._id}`}><button>Details</button></Link>
                                            <Link href={`/alldoctors/book/${doctor._id}`}> <button>Book</button></Link>
                                        </div>
                                    </div>
                            ))}
                    {/* <div className="SingleDoctor">
                        <p>Dr. Sheraz Alam</p>
                        <div className="singleDoctorsActionButtons">
                            <Link href={"/alldoctors/details/123"}><button>Details</button></Link>
                            <Link href={"/alldoctors/book/123"}> <button>Book</button></Link>
                        </div>
                    </div>
                    <div className="SingleDoctor">
                        <p>Dr. Muqadus Khalid</p>
                        <div className="singleDoctorsActionButtons">
                            <button>Details</button>
                            <button>Book</button>
                        </div>
                    </div>
                    <div className="SingleDoctor">
                        <p>Dr. Aleeza Awan</p>
                        <div className="singleDoctorsActionButtons">
                            <button>Details</button>
                            <button>Book</button>
                        </div>
                    </div> */}

                </div>
            </div>
        </>
    )
}

export default AllDoctorsList