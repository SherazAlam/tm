"use client"
import styles from "@styles/login.module.css"
import React, { useState, useEffect } from 'react'
import { signIn } from "next-auth/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react"
import { redirect } from "next/navigation";





const Login = () => {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("")
    const router = useRouter()
    const { data: session, status } = useSession()
    // const session = await getServerSession(authOptions)

    useEffect(() => {
        if (session) {
            if (session.user.role == "patient") {
                redirect("/patienthome")
            }
            else if (session.user.role == "doctor") {
                redirect("/doctorhome")
            }
            else if (session.user.role == "admin") {
                redirect("/dashboard_admin")
            }
            console.log(session)
        }
    }, [session])



    const handleLogin = async (e) => {
        e.preventDefault();
        if (!email.match(
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        )) {
            setError("Please Enter Valid Email")
            setTimeout(() => {
                setError("")
            }, 3000)
            return
        }
        if (!password) {
            setError("Please Enter Password")
            setTimeout(() => {
                setError("")
            }, 3000)
            return
        }
        try {
            const res = await signIn("credentials", {
                email, password, redirect: false
            });
            console.log("res", res)
            if (res.error) {
                console.log("Invalid Credentials")
                setError("Invalid Credentials")
                setTimeout(() => {
                    setError("")
                }, 3000)

                return
            }
            console.log("Patient: ", res)
            // router.replace("/edit_profile/patient")
        } catch (e) {
            console.log(error)
        }


    }

    return (
        <div className={`${styles.container}`}>
            <div className={`${styles.left}`}>
                <div className={`${styles.leftContent}`}>
                    <img src="/images/logo.png" alt="" />
                    <h1>Telemedicine</h1>
                </div>
            </div>
            <div className={`${styles.right}`}>
                <div className={`${styles.logo}`}>
                    <img src="/images/logo.png" alt="" />
                    <h1>Login</h1>
                </div>
                <form autoComplete="off" className={`${styles.inputFieldsContainer}`}>
                    <div className={`${styles.inputFieldsInnerContainer}`}>
                        <label htmlFor="">Email:</label>
                        <input name="email" className={`${styles.inputFields}`} type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                    </div>
                    <div className={`${styles.inputFieldsInnerContainer}`}>
                        <label htmlFor="">Password:</label>
                        <input name="password" className={`${styles.inputFields}`} type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                    </div>

                    <button className={`${styles.inputButton}`} onClick={handleLogin}>Login</button>
                    <div className="googleSignIn" onClick={() => signIn("google")} style={{ width: "max-content", display: "flex", alignItems: "center", border: "1px solid black", padding: "5px 10px", borderRadius: "5px", marginBottom: "10px", cursor: "pointer" }}>
                        <img style={{ width: "30px", height: "30px", objectFit: "cover" }} src="/icons/google.png" alt="" />
                        <p >Sign in with google</p>
                    </div>
                </form>
                <p>No account? Create <Link href={"/registration"}> here</Link></p>
                {error ?
                    <div style={{ position: "absolute", right: "20px", top: "20px", padding: "5px 20px", border: "1px solid black", backgroundColor: "maroon" }}>
                        <p style={{ color: "white" }}>{error}</p>
                    </div>
                    :
                    null}


            </div>
        </div >
    )
}

export default Login