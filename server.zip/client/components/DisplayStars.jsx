"use client"
import { Icon } from '@iconify/react'
import React from 'react'

const DisplayStars = ({stars}) => {
  return (
    <div>
        {[...Array(Number(stars))].map((star, index)=>(

    <Icon key={index} icon={"mdi:star"} width={23} height={23} style={{ color: "gold" }} />
        ))}
   
    </div>
  )
}

export default DisplayStars