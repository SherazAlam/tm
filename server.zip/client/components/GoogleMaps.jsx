"use client"
import React from 'react'
import { GoogleMap, useJsApiLoader } from '@react-google-maps/api';

// const containerStyle = {
//     width: '100%',
//     height: '400px'
// };

// const center = {
//     lat: 33.54325601260441,
//     lng: 73.05369541308528
// };

function GoogleMaps({ latitude, setLatitude, longitude, setlongitude }) {
    const { isLoaded } = useJsApiLoader({
        id: 'google-map-script',
        googleMapsApiKey: "AIzaSyBvuskP_nO-26wYoPR7AwGIutSkIdE4M9Q"
    })

    const [map, setMap] = React.useState(null)
    const containerStyle = {
        width: '100%',
        height: '400px'
    };

    const center = {
        lat: latitude,
        lng: longitude
    };
    const onLoad = React.useCallback(function callback(map) {
        // This is just an example of getting and using the map instance!!! don't just blindly copy!
        const bounds = new window.google.maps.LatLngBounds(center);
        map.fitBounds(bounds);

        setMap(map)
    }, [])

    const onUnmount = React.useCallback(function callback(map) {
        setMap(null)
    }, [])

    return isLoaded ? (
        <GoogleMap
            mapContainerStyle={containerStyle}
            center={center}
            zoom={10}
            onLoad={onLoad}
            onUnmount={onUnmount}
            onClick={ev => {
                console.log("latitide = ", ev.latLng.lat());
                setLatitude(ev.latLng.lat())
                console.log("longitude = ", ev.latLng.lng());
                setlongitude(ev.latLng.lng())
            }}
        >
            { /* Child components, such as markers, info windows, etc. */}
            <></>
        </GoogleMap>
    ) : <></>
}

export default React.memo(GoogleMaps)