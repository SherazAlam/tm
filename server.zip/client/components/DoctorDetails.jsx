"use client"
import React, { useEffect, useState } from 'react'
import "@styles/patientDetails.css"
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { Icon } from '@iconify/react';


const DoctorDetails = ({ patientRequest }) => {
    const [newDates, setNewDates] = useState({})
    const [rescheduling, setRescheduling] = useState(false)
    const { data: session } = useSession()

    const router = useRouter();

    const handleUpdate = async () => {
        console.log("d", newDates);
        if (newDates.appointmentDate && newDates.appointmentTime) {


            try {
                const res = await fetch("/api/updateAppointment", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ ...newDates, id: patientRequest._id })
                })
                if (res.ok) {
                    // const fetchedData = await res.json();
                    // console.log("Let's see", await fetchedData)
                    // alert("Data Updated Successfully!");
                    // setUserData(fetchedData.userData)
                    toast.success("Appointment Rescheduled Successfully!")


                }
                else {
                    toast.error("Some Error occurs during rescheduling!")
                }
            }
            catch (e) {
                console.log(e);
            }
        }
        else {
            toast.error("Please select new dates")
        }
    }

    useEffect(() => {
        console.log("Hello", patientRequest);
    }, [patientRequest])
    return (
        <div className="patientDetailsCardContainer">
            <div className="headerSection">
                <div className="patientDetails">
                    <div className="pfp">
                        <img src={patientRequest.doctorPfp ? patientRequest.doctorPfp : ""}></img>
                    </div>
                    <div className="patientTextDetails">
                        <h4>{patientRequest.doctorName}</h4>
                        <p>{patientRequest.appointmentDate} ( {patientRequest.appointmentTime} )</p>
                    </div>
                </div>
                <div className="patientIssues">
                    {patientRequest.symptoms && patientRequest.symptoms.map((symptom, index) => (
                        <div className="patientIssue" key={index}>
                            <div className="issueImg" style={{ width: "30px", height: "30px", backgroundColor: "#494993" }}>

                            </div>
                            <p>{symptom}</p>
                        </div>
                    ))}
                    {/* <div className="patientIssue">
                        <div className="issueImg" style={{ width: "30px", height: "30px", backgroundColor: "#494993" }}>

                        </div>
                        <p>Fever</p>
                    </div>
                    <div className="patientIssue">
                        <div className="issueImg" style={{ width: "30px", height: "30px", backgroundColor: "#494993" }}>

                        </div>
                        <p>Cough</p>
                    </div>
                    <div className="patientIssue">
                        <div className="issueImg" style={{ width: "30px", height: "30px", backgroundColor: "#494993" }}>

                        </div>
                        <p>Fever</p>
                    </div> */}
                </div>
            </div>
            <div className="patientOtherDetailsSection">
                <h4>Observations: </h4>
                <p>{patientRequest.appointmentReason}</p>
            </div>

            {rescheduling ?
                <>
                    <div className="bookDate" style={{ marginTop: "15px", marginBottom: "10px" }}>
                        <h4>Select Date</h4>
                        <input type="date" name='date' style={{ width: "100%" }} onChange={(e) => setNewDates(prev => ({ ...prev, appointmentDate: e.target.value }))} />
                    </div>
                    <div className="bookTime" >
                        <h4>Select Time</h4>
                        <input type="time" name='time' style={{ width: "100%" }} onChange={(e) => setNewDates(prev => ({ ...prev, appointmentTime: e.target.value }))} />
                    </div>
                    
                    <div className='patientDetailsBtns'>
                        <button onClick={handleUpdate}>Reschedule</button>
                    </div>
                </>

                :

                <div className='patientDetailsBtns'>
                    {session?.user?.role == "doctor" ?
                    
                    <button onClick={() => setRescheduling(true)}>Reschedule</button>
                :
                ""
                }
                    {/* <button onClick={() => router.push({
                        pathname: "/videocall",
                        query: { test: "hello" }
                    })}>Start Call</button> */}
                    {session?.user?.role == "doctor" ?
                    
                    <Link
                        href={`/videocall/${patientRequest._id}`}
                    >
                        <button>Start Call</button>
                    </Link>
                
                :
                session?.user?.role == "patient" ?
patientRequest.appointmentSession == "started" ?
<Link
href={`/videocall/${patientRequest._id}`}
>
<button>Start Call</button>

</Link>
:
<>
<button disabled={true} style={{cursor: "not-allowed", backgroundColor: "rgba(73, 73, 147, 0.5"}}>Start Call</button>
<div style={{display: "flex", gap: "5px", alignItems: "center", marginTop: "10px"}}>
<p style={{fontSize: "14px"}}>*Doctor has not started the call yet.</p>
<Icon icon="tabler:reload" width="22" height="22"  style={{color: "#494993", cursor: "pointer"}} onClick={()=>location.reload()} />
</div>
</>
                :
                ""
                }
                </div>}
            <ToastContainer />

        </div>
    )
}

export default DoctorDetails