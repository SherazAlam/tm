"use client"
import React, { useEffect, useState } from 'react'
import PatientDetails from './PatientDetails'

const PatientRequests = ({ appointmentRequests }) => {
    useEffect(() => {
        console.log("sd", appointmentRequests);
        let temp = appointmentRequests.appointments.map((request) => {
            let patientDob = new Date(request.patientDob);
            let dateNow = new Date(Date.now());
            console.log("s", Number(patientDob.getFullYear()));
            console.log("d", Number(dateNow.getFullYear()));
            let age = Number(dateNow.getFullYear()) - Number(patientDob.getFullYear());
            console.log("age", age);
            let symptoms = request.appointmentSymptoms.split(",");
            return (
                { ...request, age: age, symptoms }
            )
        })
        setAppointmentRequestState(temp)
    }, [])
    const [selectedPatientIndex, setSelectedPatientIndex] = useState(0)
    const [appointmentRequestsState, setAppointmentRequestState] = useState(appointmentRequests.appointments)
    return (
        <>
            <div className="patientList">
                
                <h4>Patient List</h4>
                {appointmentRequests && appointmentRequests.appointments ? appointmentRequests.appointments.map((appointmentRequest, index) => (
                    <div className="singlePatient" onClick={() => setSelectedPatientIndex(index)} key={index}>

                        <div className="patientDetails">
                            <div className="pfp">
                                <img src={appointmentRequest.patientPfp ? appointmentRequest.patientPfp : ""}></img>
                            </div>
                            <div className="patientTextDetails">
                                <h4>{appointmentRequest.patientName}</h4>
                                <p>{appointmentRequest.appointmentDate}</p>
                            </div>
                        </div>
                        <div className="appointmentTime">
                            <p>{appointmentRequest.appointmentTime}</p>
                        </div>
                    </div>
                ))
                    :
                    "No Patient Requests Found"}
                {/* <div className="singlePatient">

                    <div className="patientDetails">
                        <div className="pfp">

                        </div>
                        <div className="patientTextDetails">
                            <h4>Sheraz Alam</h4>
                            <p>New Patient</p>
                        </div>
                    </div>
                    <div className="appointmentTime">
                        <p>9:30 AM</p>
                    </div>
                </div>
                <div className="singlePatient">

                    <div className="patientDetails">
                        <div className="pfp">

                        </div>
                        <div className="patientTextDetails">
                            <h4>Muqadus Khalid</h4>
                            <p>New Patient</p>
                        </div>
                    </div>
                    <div className="appointmentTime">
                        <p>10:30 AM</p>
                    </div>
                </div>
                <div className="singlePatient">

                    <div className="patientDetails">
                        <div className="pfp">

                        </div>
                        <div className="patientTextDetails">
                            <h4>Aleeza Awan</h4>
                            <p>New Patient</p>
                        </div>
                    </div>
                    <div className="appointmentTime">
                        <p>11:30 AM</p>
                    </div>
                </div>
                <div className="singlePatient">

                    <div className="patientDetails">
                        <div className="pfp">

                        </div>
                        <div className="patientTextDetails">
                            <h4>Aleeza Awan</h4>
                            <p>New Patient</p>
                        </div>
                    </div>
                    <div className="appointmentTime">
                        <p>11:30 AM</p>
                    </div>
                </div>
                <div className="singlePatient">

                    <div className="patientDetails">
                        <div className="pfp">

                        </div>
                        <div className="patientTextDetails">
                            <h4>Aleeza Awan</h4>
                            <p>New Patient</p>
                        </div>
                    </div>
                    <div className="appointmentTime">
                        <p>11:30 AM</p>
                    </div>
                </div>
                <div className="singlePatient">

                    <div className="patientDetails">
                        <div className="pfp">

                        </div>
                        <div className="patientTextDetails">
                            <h4>Aleeza Awan</h4>
                            <p>New Patient</p>
                        </div>
                    </div>
                    <div className="appointmentTime">
                        <p>11:30 AM</p>
                    </div>
                </div>
                <div className="singlePatient">

                    <div className="patientDetails">
                        <div className="pfp">

                        </div>
                        <div className="patientTextDetails">
                            <h4>Aleeza Awan</h4>
                            <p>New Patient</p>
                        </div>
                    </div>
                    <div className="appointmentTime">
                        <p>11:30 AM</p>
                    </div>
                </div>
                <div className="singlePatient">

                    <div className="patientDetails">
                        <div className="pfp">

                        </div>
                        <div className="patientTextDetails">
                            <h4>Aleeza Awan</h4>
                            <p>New Patient</p>
                        </div>
                    </div>
                    <div className="appointmentTime">
                        <p>11:30 AM</p>
                    </div>
                </div>
                <div className="singlePatient">

                    <div className="patientDetails">
                        <div className="pfp">

                        </div>
                        <div className="patientTextDetails">
                            <h4>Aleeza Awan</h4>
                            <p>New Patient</p>
                        </div>
                    </div>
                    <div className="appointmentTime">
                        <p>11:30 AM</p>
                    </div>
                </div> */}


            </div>
            {appointmentRequests && appointmentRequests.appointments && appointmentRequests.appointments.length > 0 ?
                <div className="patientDetailsContainer">
                    <h4>Patient Details</h4>
                    <PatientDetails patientRequest={appointmentRequestsState[selectedPatientIndex]}></PatientDetails>
                </div>
                :
<div>
                <p>No Patient Requests found!</p>
                </div>}
        </>
    )
}

export default PatientRequests