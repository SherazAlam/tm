"use client";
import React, { useState, useRef } from "react";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";


export default function Accordion({ prescriptions }) {
  const printRef = useRef();

  const [openSection, setOpenSection] = useState(null);

  const toggleSection = (section) => {
    setOpenSection(openSection === section ? null : section);
  };

  const handleDownloadPdf = async () => {
    const element = printRef.current;
    const canvas = await html2canvas(element);
    const data = canvas.toDataURL("image/png");

    const pdf = new jsPDF("p", "mm", "a4");
    const imgProperties = pdf.getImageProperties(data);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProperties.height * pdfWidth) / imgProperties.width;

    pdf.addImage(data, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save("prescription.pdf");
  };

  return (
    <div className="accordion" ref={printRef}>
      {!prescriptions ? (
        <div>
          <p
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              margin: "20px",
              fontSize: "28px",
              fontWeight: "bold",
              color: "skyblue",
            }}
          >
            No Prescription Yet Please{" "}
            <span style={{ color: "green" }}>Ask The Doctor To Add</span>
          </p>
        </div>
      ) : (
        prescriptions?.map((prescription, index) => (
          <div
            className="accordion-item"
            key={index}
            style={{
              border: "1px solid #ccc",
              marginBottom: "10px",
              borderRadius: "5px",
              overflow: "hidden",
            }}
          >
            <div
              className="accordion-header"
              onClick={() => toggleSection(index)}
              style={{
                backgroundColor: "#494993",
                cursor: "pointer",
              }}
            >
              <button
                className="accordion-button"
                style={{
                  width: "100%",
                  textAlign: "left",
                  padding: "15px",
                  fontSize: "18px",
                  border: "none",
                  background: "none",
                  cursor: "pointer",
                  color: "white"
                }}
              >
                Prescription {index + 1}
              </button>
            </div>
            <div
              className={`accordion-content ${
                openSection === index ? "show" : ""
              }`}
              style={{
                padding: "15px",
                display: openSection === index ? "block" : "none",
              }}
            >
              <p>
                <strong>Doctor ID:</strong> {prescription.doctorId}
              </p>
              <p>
                <strong>Date Issued:</strong>{" "}
                {new Date(prescription.dateIssued).toLocaleDateString()}
              </p>
              <p>
                <strong>Medication Name:</strong> {prescription.medicationName}
              </p>
              <p>
                <strong>Dosage:</strong> {prescription.dosage}
              </p>
              <p>
                <strong>Strength:</strong> {prescription.strength}
              </p>
              <p>
                <strong>Form:</strong> {prescription.form}
              </p>
              <p>
                <strong>Quantity:</strong> {prescription.quantity}
              </p>
              <p>
                <strong>Instructions:</strong> {prescription.instructions}
              </p>
              <p>
                <strong>Duration:</strong> {prescription.duration}
              </p>
              <div
                className="download-button-container"
                style={{
                  display: "flex",
                  justifyContent: "end",
                  marginTop: "20px",
                }}
              >
                <button
                  className="download-button"
                  onClick={handleDownloadPdf}
                  style={{
                    backgroundColor: "#007bff",
                    color: "white",
                    border: "none",
                    padding: "10px 20px",
                    fontSize: "16px",

                    cursor: "pointer",
                    borderRadius: "5px",
                    transition: "background-color 0.3s",
                  }}
                  onMouseEnter={(e) =>
                    (e.target.style.backgroundColor = "#0056b3")
                  }
                  onMouseLeave={(e) =>
                    (e.target.style.backgroundColor = "#007bff")
                  }
                >
                  Download PDF
                </button>
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
