import React from 'react'
import "../styles/homepage.css"
import Link from 'next/link'

const Homepage = () => {
    return (
        <>
            <div className="div">
                <div className="div-14">
                    <div className="div-15">
                        <div className="div-16">
                            <div className="div-17">TELEMEDICINE</div>
                            <div className="div-18">
                                <div className="div-19">
                                    <div className="div-20">How It works</div>
                                    <a href='#departments' style={{ textDecoration: "none" }}><div className="div-21">Departments</div></a>
                                    <a href='#about' style={{ textDecoration: "none" }}> <div className="div-22">About Us</div></a>

                                </div>
                                <div className="div-25">
                                    <Link href="/login">
                                        <div className="div-26">Sign In</div>
                                    </Link>
                                </div>
                            </div>
                        </div>
                        <div className="div-27">
                            <div className="div-28">

                                <div className="column-2">
                                    <div className="div-29">
                                        <div className="div-30">
                                            <span style={{ fontFamily: "Roboto, sans-serif", fontWeight: "300" }}>
                                                We're
                                            </span>
                                            <span style={{ fontFamily: "Roboto, sans-serif", fontWeight: "700" }}>

                                                {" "}
                                                determined{" "}
                                            </span>
                                            <span style={{ fontFamily: "Roboto, sans-serif", fontWeight: "300" }}>

                                                for your
                                            </span>
                                            <span style={{ fontFamily: "Roboto, sans-serif", fontWeight: "700" }}>

                                                {" "}
                                                better life.
                                            </span>
                                        </div>{" "}
                                        <div className="div-31">
                                            You can get the care you need 24/7 – be it online or in
                                            person. You will be treated by caring specialist doctors.
                                        </div>{" "}
                                        <div className="div-32">
                                            <div className="div-33">Make an Appointment</div>
                                        </div>
                                    </div>
                                </div>{" "}
                                <div className="column-3">
                                    <div className="div-34">
                                        <img
                                            loading="lazy"
                                            src="https://cdn.builder.io/api/v1/image/assets/TEMP/3a522905-b38b-40c1-995d-60b3a8793203?"
                                            className="img-2"
                                        />{" "}
                                        <div className="div-35">
                                            <div className="div-36" /> <div className="div-37" />
                                        </div>{" "}
                                        <div className="div-38">
                                            <div className="div-39" /> <div className="div-40" />
                                        </div>{" "}
                                        <div className="div-41">
                                            <div className="div-42" /> <div className="div-43" />
                                        </div>{" "}
                                        <div className="div-44">
                                            <div className="div-45" /> <div className="div-46" />
                                        </div>{" "}
                                        <div className="div-47">
                                            <div className="div-48" /> <div className="div-49" />
                                        </div>
                                    </div>
                                </div>{" "}

                            </div>
                        </div>{" "}
                        <div className="div-71" id='departments'>OUR DEPARTMENTS</div>{" "}
                        <div className="div-72">
                            <div className="div-73">
                                <img
                                    loading="lazy"
                                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/6c704c5f-ff14-47aa-99ad-8931294c5f88?"
                                    className="img-3"
                                />{" "}
                                <div className="div-74">Neurology</div>
                            </div>{" "}
                            <div className="div-75">
                                <img
                                    loading="lazy"
                                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/dd7d47d5-41ad-4bce-81ab-6c11ca8d68b8?"
                                    className="img-4"
                                />{" "}
                                <div className="div-76">Eye care</div>
                            </div>{" "}
                            <div className="div-77">
                                <img
                                    loading="lazy"
                                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/64e76f71-78f5-4050-a8c6-8e3124ea7d8f?"
                                    className="img-5"
                                />{" "}
                                <div className="div-78">Cardiac care</div>
                            </div>{" "}
                            <div className="div-79">
                                <img
                                    loading="lazy"
                                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/a1a751df-3d2a-462d-88d2-f84533d0a48b?"
                                    className="img-6"
                                />{" "}
                                <div className="div-80">Heart care</div>
                            </div>{" "}
                            <div className="div-81">
                                <img
                                    loading="lazy"
                                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/b4d362e4-89c3-4614-b7e4-9d493b658130?"
                                    className="img-7"
                                />{" "}
                                <div className="div-82">Osteoporosisi</div>
                            </div>{" "}
                            <div className="div-83">
                                <img
                                    loading="lazy"
                                    src="https://cdn.builder.io/api/v1/image/assets/TEMP/54dba092-d7db-4797-a332-726fd1eb3461?"
                                    className="img-8"
                                />{" "}
                                <div className="div-84">ENT</div>
                            </div>
                        </div>{" "}
                        <div className="div-85">
                            <div className="div-86">
                                <div className="div-87">
                                    <div className="column-5">
                                        <div className="div-88">
                                            <div className="div-89">
                                                <div className="div-90" /> <div className="div-91" />
                                            </div>{" "}
                                            <div className="div-92">
                                                <div className="div-93" /> <div className="div-94" />
                                            </div>{" "}
                                            <div className="div-95">
                                                <div className="div-96" /> <div className="div-97" />
                                            </div>{" "}
                                            <div className="div-98">
                                                <div className="div-99" /> <div className="div-100" />
                                            </div>{" "}
                                            <div className="div-101">
                                                <div className="div-102" /> <div className="div-103" />
                                            </div>
                                        </div>
                                    </div>{" "}
                                    <div className="column-6">
                                        <div className="div-104">
                                            <img
                                                loading="lazy"
                                                srcSet="/images/Photo.png"
                                                className="img-9"
                                            />{" "}
                                            <div className="div-105">
                                                <div className="div-106" /> <div className="div-107" />{" "}
                                                <div className="div-108" />
                                            </div>{" "}
                                            <div className="div-109">
                                                <div className="div-110" /> <div className="div-111" />{" "}
                                                <div className="div-112" />
                                            </div>{" "}
                                            <div className="div-113">
                                                <div className="div-114" /> <div className="div-115" />{" "}
                                                <div className="div-116" />
                                            </div>{" "}
                                            <div className="div-117">
                                                <div className="div-118" /> <div className="div-119" />{" "}
                                                <div className="div-120" />
                                            </div>{" "}
                                            <div className="div-121">
                                                <div className="div-122" /> <div className="div-123" />{" "}
                                                <div className="div-124" />
                                            </div>
                                        </div>
                                    </div>{" "}
                                    <div className="column-7">
                                        <div className="div-125">

                                            <div className="div-127">
                                                <div className="div-128">
                                                    Eye Care with Top Professionals and In Budget.
                                                </div>{" "}
                                                <div className="div-129">
                                                    We've built a healthcare system that puts your needs
                                                    first. <br />
                                                    For us, there is nothing more important than the
                                                    health of
                                                    <br />
                                                    you and your loved ones.
                                                </div>
                                                <div className="div-130">
                                                    <div className="div-131">
                                                        <div className="div-132">Learn More</div>
                                                    </div>
                                                    <img
                                                        loading="lazy"
                                                        src="https://cdn.builder.io/api/v1/image/assets/TEMP/e439d702-c64c-4a24-9070-95a9bb6d3508?"
                                                        className="img-10"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="div-133">
                            <div className="div-134">

                                <div className="column-9">
                                    <div className="div-135">
                                        <div className="div-136">
                                            <div className="div-137" id='about'>ABOUT US</div>
                                            <div className="div-138">
                                                <div className="div-139">
                                                    <div className="div-140" />
                                                    <div className="div-141" />
                                                    <div className="div-142" />
                                                    <div className="div-143" />
                                                    <div className="div-144" />
                                                </div>
                                                <div className="div-145">
                                                    <div className="div-146" />
                                                    <div className="div-147" />
                                                    <div className="div-148" />
                                                    <div className="div-149" />
                                                    <div className="div-150" />
                                                </div>
                                                <div className="div-151">
                                                    <div className="div-152" />
                                                    <div className="div-153" />
                                                    <div className="div-154" />
                                                    <div className="div-155" />
                                                    <div className="div-156" />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="div-157">
                                            <div className="div-158">
                                                <div className="column-10">
                                                    <div className="div-159">
                                                        <div className="div-160">
                                                            <div className="column-11">
                                                                <div className="div-161">
                                                                    <div className="div-162">
                                                                        We are developing a healthcare system around
                                                                        you
                                                                    </div>
                                                                    <div className="div-163">
                                                                        We think that everyone should have easy
                                                                        access to excellent healthcare. Our aim is
                                                                        to make the procedure as simple as possible
                                                                        for our patients and to offer treatment no
                                                                        matter where they are — in person or at
                                                                        their convenience.
                                                                    </div>
                                                                    <div className="div-164">
                                                                        <div className="div-165">Learn more</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className="column-12">
                                                                <img
                                                                    loading="lazy"
                                                                    srcSet="/images/Photo2.png"
                                                                    className="img-12"
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>


                    <div className="div-375">
                        <div className="div-376">
                            <div className="div-377" />
                            <div className="div-378" />
                            <div className="div-379" />
                            <div className="div-380" />
                            <div className="div-381" />
                        </div>
                        <div className="div-382">
                            <div className="div-383" />
                            <div className="div-384" />
                            <div className="div-385" />
                            <div className="div-386" />
                            <div className="div-387" />
                        </div>
                        <div className="div-388">
                            <img
                                loading="lazy"
                                src="https://cdn.builder.io/api/v1/image/assets/TEMP/4c8a0428-cd28-4370-b623-e638335fbdf6?"
                                className="img-34"
                            />
                            <div className="div-389">
                                <div className="div-390" />
                                <div className="div-391" />
                                <div className="div-392" />
                                <div className="div-393" />
                                <div className="div-394" />
                            </div>
                            <div className="div-395">
                                <div className="div-396">
                                    Telemedicine cares about You!
                                    <br />
                                </div>
                                <div className="div-398">
                                    <div className="div-399" />
                                    <div className="div-400" />
                                    <div className="div-401" />
                                    <div className="div-402" />
                                    <div className="div-403" />
                                </div>
                            </div>
                            <div className="div-404">
                                <div className="div-405">
                                    Telemedicine was created in order to improve the patient
                                    experience. Providing world-class tests, and a wide range of
                                    other services.
                                </div>

                            </div>
                            <img
                                loading="lazy"
                                src="https://cdn.builder.io/api/v1/image/assets/TEMP/20a409ee-cc1f-4bf6-88cc-ee34ac47c545?"
                                className="img-35"
                            />
                            <div className="div-416">
                                <div className="div-417">
                                    <div className="div-418">
                                        <div className="div-419">TELEMEDICINE</div>
                                        <div className="div-420">
                                            The world's most trusted <br />
                                            telehealth company.
                                        </div>
                                    </div>{" "}
                                    <div className="div-421">
                                        <div className="div-422">Quick Links</div>{" "}
                                        <div className="div-423">How it works</div>{" "}
                                        <div className="div-424">About us</div>{" "}
                                        <div className="div-425">Membership</div>
                                    </div>{" "}
                                    <div className="div-426">
                                        <div className="div-427">Departments</div>{" "}
                                        <div className="div-428">Eye care</div>{" "}
                                        <div className="div-429">Cardiac are</div>{" "}
                                        <div className="div-430">Heart care</div>
                                    </div>{" "}
                                    <div className="div-431">
                                        <div className="div-432">Membership</div>{" "}
                                        <div className="div-433">Free trial</div>{" "}
                                        <div className="div-434">Silver</div>{" "}
                                        <div className="div-435">Premium</div>
                                    </div>{" "}
                                    <div className="div-436">
                                        <div className="div-437">Customer Care</div>{" "}
                                        <div className="div-438">About Us</div>{" "}
                                        <div className="div-439">Contact US</div>{" "}
                                        <div className="div-440">Get Update</div>
                                    </div>{" "}
                                    <img
                                        loading="lazy"
                                        src="https://cdn.builder.io/api/v1/image/assets/TEMP/3e01fde5-685a-48c5-9ecf-b84d797f11b2?"
                                        className="img-36"
                                    />
                                </div>
                            </div>{" "}
                            <div className="div-441">
                                <div className="div-442">
                                    All rights Reserved © Telemedicine, 2023
                                </div>{" "}
                                {/* <div className="div-443">
                                    <span style={{ fontFamily: "Roboto, sans-serif", fontWeight: "300", color: "rgba(224,222,222,1)" }}>

                                        Made with love by
                                    </span>
                                    <span style={{ fontFamily: "Roboto, sans-serif", fontWeight: "500", color: "rgba(224,222,222,1)" }}>

                                    </span> */}
                                {/* <span style="font-family: Roboto, sans-serif;font-weight: 700;color: rgba(178,221,237,1);"> */}

                                {/* </div> */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Homepage