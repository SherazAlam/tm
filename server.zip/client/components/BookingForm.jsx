"use client"

import axios from 'axios';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import React from 'react'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { loadStripe } from '@stripe/stripe-js';


const BookingForm = ({ doctorData, userData }) => {
    const router = useRouter();
    const handleFormSubmit = async (e) => {
        e.preventDefault();


              //Payment

              const stripe = await loadStripe('pk_test_51OFrhCA8Z7XYs2EGhmpaLrnsI6NLc0u34OqER9RF0sO9R5SNeWioaqFyEnmzVRjBf0SOx7PPeT1IVVLk41vdgaJu00etitUgAj');

              try {
                
                
               
               
              }
              catch (e) {
                // console.log("Error Making a post request to Stripe Route", e);
              
              }
              
              //


        const { user } = userData;
        console.log("hehe");
        console.log("ud", userData);
        console.log("ud", doctorData);
        console.log("d", e.target.elements.date.value);
        console.log("d", e.target.elements.time.value);
        console.log("dd", e.target.elements.appointmentType.value);
        console.log("ddd", Date.now());
        console.log("Obj", {
            appointmentType: e.target.elements.appointmentType.value,
            appointmentDate: e.target.elements.date.value,
            appointmentTime: e.target.elements.time.value,
            appointmentSymptoms: e.target.elements.appointmentSymtoms.value,
            appointmentReason: e.target.elements.appointmentReason.value,
            createdAt: String(Date.now()),
            doctorName: doctorData.name,
            doctorEmail: doctorData.email,
            doctorId: doctorData._id,
            patientName: user.name,
            patientEmail: user.email,
            patientId: user.id,
            patientDob: user.dateOfBirth,
            patientGender: user.gender,
            lastUpdatedBy: user.role,
            lastUpdatedAt: String(Date.now()),
            appointmentReason: "flu",
            appointmentSymptoms: "fly cough"
        });
        try {
             // const response = await axios.post("http://localhost:8080/create-checkout-session", {
                //   name: name,
                //   price: price,
                //   userId: auth.currentUser.uid
                // });
                const response = await axios.post("http://localhost:8080/create-checkout-session", {
                  name: "Dr. " + doctorData.name + "'s Appointment",
                  price: 1500,
                  
                });
              
                // console.log(response.data);
              
                const session = response.data
            
            const res = await fetch(`/api/bookDoctor`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    appointmentType: e.target.elements.appointmentType.value,
                    appointmentDate: e.target.elements.date.value,
                    appointmentTime: e.target.elements.time.value,
                    appointmentSymptoms: e.target.elements.appointmentSymtoms.value,
                    appointmentReason: e.target.elements.appointmentReason.value,
                    createdAt: String(Date.now()),
                    doctorName: doctorData.name,
                    doctorEmail: doctorData.email,
                    doctorId: doctorData._id,
                    patientName: user.name,
                    patientEmail: user.email,
                    patientId: user.id,
                    patientDob: user.dateOfBirth,
                    patientGender: user.gender,
                    lastUpdatedBy: user.role,
                    lastUpdatedAt: String(Date.now()),
                    patientPfp: user.image,
                    doctorPfp: doctorData.pfp,
                    appointmentSession: "notStarted",
                    paymentStatus: "unpaid",
                    paymentSessionId: session.id,
                    appointmentCompleted: false

                })
            })
            if (res.ok) {
                const fetchedData = await res.json();
                console.log("Let's see", fetchedData)
                // redirect("/successpage")

                // setuserData(fetchedData.userData)
                const result = stripe.redirectToCheckout({
                    sessionId: session.id
                  })
                  if (result.error) {
                    // console.log(result.error);
                    // setLoading(false)
                  }

                console.log("yesss");
                
                
                
  


                // toast.success("Appointment Successfully Booked!")
                // const result = await axios.post("http://localhost:8080/sendmessage", {
                //     doctorName: doctorData.name,
                //     doctorNumber: doctorData.phone,
                //     patientName: user.name
                // })
                // if (result) {
                //     console.log("sms result", result.data);
                // }
                // router.replace("/alldoctors")



            }
            else {
                toast.error("Some Error occurs during booking");
            }
        }
        catch (e) {
            console.log(e);
        }
        console.log(e.target.element);
    }

const getCurrentDate = () => {
    let nowDate = new Date();
    let year, date, month;
    console.log("ddddds", nowDate.getDate());
    if (nowDate.getMonth()+1 < 10){
        month = "0" + String(nowDate.getMonth()+1)
    }
    else{
        month = nowDate.getMonth()+1;
    }
    if (nowDate.getDate() < 10){
        date = "0" + String(nowDate.getDate())
    }
    else{
        date = nowDate.getDate();
    }
    console.log("dddddd", String(nowDate.getFullYear()+"-"+month+"-"+year ));
    return String(nowDate.getFullYear()+"-"+month+"-"+date  )
}
    return (
        <>
            <form onSubmit={handleFormSubmit}>
                <div className="bookDoctor">
                    <h1>{"Dr. " + doctorData?.name + "'s Appointment"}</h1>
                    <div className="bookDate">
                        <h4>Appointment Type</h4>
                        <select name='appointmentType'>
                            <option value="online" selected>Online</option>
                            <option value="physical">Physical</option>
                        </select>
                    </div>
                    <div className="bookDate">
                        <h4>Select Date</h4>
                        <input type="date" name='date' min={getCurrentDate()} />
                    </div>
                    <div className="bookTime">
                        <h4>Select Time</h4>
                        <input type="time" name='time' />
                    </div>
                    <div className="bookDate">
                        <h4>Appointment Symptoms</h4>
                        <input type="text" name='appointmentSymtoms' placeholder='Enter Comma Separated values (e.g flu, cough)' />
                    </div>
                    <div className="bookDate">
                        <h4>Appointment Reason</h4>
                        <textarea type="text" name='appointmentReason' placeholder='I am feeling like...' ></textarea>
                    </div>
                    <div className="bookButtons">
                        <Link href={"/alldoctors"}>  <button className='cancelBtn'>Cancel</button></Link>
                        <button type='submit' className='confirmBtn'>Confirm</button>
                    </div>
                </div>
            </form>
            <ToastContainer />
        </>
    )
}

export default BookingForm