"use client"
import styles from "@styles/register.module.css"

import React from 'react'
import Link from "next/link"

const Welcome = ({ setSelected, data, setData, setError }) => {
    const handleNext = () => {
        if (data.email == null || data.email == "" || !data.email.match(
            /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        )) {
            setError("Please enter correct email");
            const timeOutId = setTimeout(() => {
                setError("")
            }, 2000)
            console.log("Timeout Id ", timeOutId);
        }
        else {

            setSelected("security")
        }
    }
    return (
        <div className={`${styles.rightEmail}`}>
            <div className={`${styles.logo}`}>
                {/* <img src="/images/logo.png" alt="" /> */}
                <h1>Welcome!</h1>
                <p>Fill in the data to create your account</p>
            </div>
            <form autoComplete="off" className={`${styles.inputFieldsContainer}`}>

                <div className={`${styles.inputFieldsInnerContainer}`}>
                    <label htmlFor="">Email:</label>
                    <input name="email" value={data?.email} className={`${styles.inputFields}`} type="email" onChange={(e) => { setData((prev) => ({ ...prev, [e.target.name]: e.target.value })) }} />
                </div>
                <div className={`${styles.inputButtonContainer}`} >

                    <button type="button" className={`${styles.inputButton}`} onClick={handleNext}>Next</button>
                </div>
            </form>
            <p>Already Registered? Login <Link href={"/login"}> here</Link></p>
        </div>
    )
}

export default Welcome

