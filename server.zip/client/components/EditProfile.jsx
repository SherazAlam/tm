"use client"
import React, { useEffect, useState } from 'react'
import "@styles/editProfile.css"
import { useSession } from "next-auth/react"
import { redirect } from 'next/navigation';
import { signOut } from "next-auth/react";
import { getDownloadURL, ref, uploadBytes } from 'firebase/storage';
import { storage } from '@config';
import GoogleMaps from './GoogleMaps';



const EditProfile = () => {
    const [userData, setUserData] = useState({});
    const [error, setError] = useState("");
    const { data: session, status } = useSession()
    // const session = await getServerSession(authOptions)
    const [newPic, setNewPic] = useState()
    const [latitude, setLatitude] = useState(33.5563648242024)
    const [longitude, setlongitude] = useState(73.06085915333769)

    useEffect(() => {
        if (!session) {
            redirect("/login")
        }
    }, [session])
    const handleGetLocation = () => {
        navigator.geolocation.getCurrentPosition((position) => {
            console.log(position.coords);
            setLatitude(position.coords.latitude);
            setlongitude(position.coords.longitude);
        })
    }
    // useEffect(() => {

    // }, [])

    const handleFetchData = async () => {
        try {
            const res = await fetch("/api/getData", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ ...userData, role: session ? session.user ? session.user.role : "" : "", email: session ? session.user ? session.user.email : "" : "" })
            })
            if (res.ok) {
                const fetchedData = await res.json();
                console.log("Let's see", await fetchedData)

                setUserData(fetchedData.userData)
                if (fetchedData.userData.latitude) {
                    setLatitude(fetchedData.userData.latitude);
                }
                if (fetchedData.user.longitude) {
                    setlongitude(fetchedData.user.longitude);
                }


            }
            else {
                setError("Some Error occurs during registration!")
            }
        }
        catch (e) {
            console.log(e);
        }
    }

    useEffect(() => {
        if (session) {

            console.log("Here");
            handleFetchData();
        }
    }, [session])



    const handleDeleteProfile = async () => {

        try {
            const res = await fetch("/api/delete", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(userData)
            })
            if (res.ok) {
                // const fetchedData = await res.json();
                // console.log("Let's see", await fetchedData)
                alert("Account Deleted Successfully!");
                // setUserData(fetchedData.userData)
                signOut();


            }
            else {
                setError("Some Error occurs during registration!")
            }
        }
        catch (e) {
            console.log(e);
        }

    }

    const handleUpdateProfile = async () => {

        if (newPic) {

            const storageRef = ref(storage, `/${session.user.name}/pfp`);

            // 'file' comes from the Blob or File API
            await uploadBytes(storageRef, newPic).then((snapshot) => {
                // console.log('Uploaded a blob or file!');
                getDownloadURL(snapshot.ref).then(async (url) => {
                    const res = await fetch("/api/update", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({ ...userData, pfp: url, latitude: latitude, longitude: longitude })
                    })
                    if (res.ok) {
                        // const fetchedData = await res.json();
                        // console.log("Let's see", await fetchedData)
                        alert("Data Updated Successfully!");
                        // setUserData(fetchedData.userData)


                    }
                    else {
                        setError("Some Error occurs during registration!")
                    }
                }).catch((error) => {
                    // console.log("Picture Uploading Error", error);
                });
            });
        }
        else {




            try {
                const res = await fetch("/api/update", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(userData)
                })
                if (res.ok) {
                    // const fetchedData = await res.json();
                    // console.log("Let's see", await fetchedData)
                    alert("Data Updated Successfully!");
                    // setUserData(fetchedData.userData)


                }
                else {
                    setError("Some Error occurs during registration!")
                }
            }
            catch (e) {
                console.log(e);
            }
        }

    }

    const handleChange = (e) => {
        setUserData((prev) => ({ ...prev, [e.target.name]: e.target.value }))
    }

    return (
        <div className="editProfileContainer">
            <div className="fieldsWithImageContainer">
                <div className="left">
                    <label htmlFor="pfp">

                        <img src={newPic ? URL.createObjectURL(newPic) : userData.pfp} alt="" />
                    </label>
                    <input type="file" name="pfp" id="pfp" accept="image/png, image/gif, image/jpeg" style={{ display: "none" }} onChange={(e) => setNewPic(e.target.files[0])} />

                </div>
                <div className="right">
                    <div className="fieldsContainer">
                        <div className="fields fieldsfull">
                            <label htmlFor="">Name</label>
                            <input name="name" type="text" value={userData.name} onChange={handleChange} />
                        </div>



                    </div>
                    <div className="fieldsContainer">
                        <div className="fields">
                            <label htmlFor="">Phone</label>
                            <input name='phone' type="text" value={userData.phone} onChange={handleChange} />
                        </div>
                        <div className="fields">
                            <label htmlFor="">Multiple Birth</label>
                            <select name="multiBirth" id="" value={userData.multiBirth} onChange={handleChange}>
                                <option value="">Select</option>
                                <option value="true">True</option>
                                <option value="false">False</option>
                            </select>
                        </div>



                    </div>
                    <div className="fieldsContainer">
                        <div className="fields">
                            <label htmlFor="">Gender</label>
                            <select name="gender" id="" value={userData.gender} onChange={handleChange}>
                                <option value="">Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="nonBinary">Non-Binary</option>
                            </select>
                        </div>

                        <div className="fields">
                            <label htmlFor="">Date of Birth</label>
                            <input name='dateOfBirth' type="date" value={userData.dateOfBirth} onChange={handleChange} />
                        </div>

                        <div className="fields">
                            <label htmlFor="">Marital Status</label>
                            <select name="maritalStatus" id="" value={userData.maritalStatus} onChange={handleChange}>
                                <option value="">Marital Status</option>

                                <option value="single" >Single</option>
                                <option value="Married">Married</option>
                                <option value="Widowed">Widowed</option>
                            </select>
                        </div>

                    </div>
                    <div className="fieldsContainer">
                        <div className="fields fieldsfull">
                            <label htmlFor="">Address</label>
                            <input name="address" type="text" value={userData.address} onChange={handleChange} />
                        </div>



                    </div>
                    {/* <div className="fieldsContainer">
                        <div className="fields">
                            <label htmlFor="">Gender</label>
                            <select name="gender" id="">
                                <option value="Male">Male</option>
                                <option value="Male">Female</option>
                                <option value="Male">Non-Binary</option>
                            </select>
                        </div>

                        <div className="fields">
                            <label htmlFor="">Phone</label>
                            <input type="text" />
                        </div>

                    </div> */}
                    {userData ? userData.role == "patient" ? <>
                        <h1 style={{ marginTop: "20px", marginBottom: "-10px" }}>Person's Contact</h1>
                        <div className="fieldsContainer">
                            <div className="fields fieldsfull">
                                <label htmlFor="">Name</label>
                                <input name="contactName" type="text" value={userData.contactName} onChange={handleChange} />
                            </div>



                        </div>
                        <div className="fieldsContainer">
                            <div className="fields">
                                <label htmlFor="">Phone</label>
                                <input name='contactPhone' type="text" value={userData.contactPhone} onChange={handleChange} />
                            </div>
                            <div className="fields">
                                <label htmlFor="">Relation</label>
                                <input name='contactRelation' type="text" value={userData.contactRelation} onChange={handleChange} />
                            </div>



                        </div>
                        <div className="fieldsContainer">
                            <div className="fields">
                                <label htmlFor="">Organization</label>
                                <input name='contactOrganization' type="text" value={userData.contactOrganization} onChange={handleChange} />
                            </div>
                            <div className="fields">
                                <label htmlFor="">Period</label>
                                <input name='contactPeriod' type="date" value={userData.contactPeriod} onChange={handleChange} />
                            </div>



                        </div>
                    </>
                        :
                        <>
                            <h2 style={{ marginTop: "10px" }}>Select Your Location</h2>
                            <div className="fieldsContainer">
                                <div className="fields">
                                    <label htmlFor="">Latitude</label>
                                    <input name='contactPhone' type="text" value={latitude} onChange={(e) => setLatitude(e.target.value)} />
                                </div>
                                <div className="fields">
                                    <label htmlFor="">Longitude</label>
                                    <input name='contactRelation' type="text" value={longitude} onChange={(e) => setlongitude(e.target.value)} />
                                </div>



                            </div>
                            <button style={{ width: "100px", height: "30px", backgroundColor: "#494993", color: "white", border: "none", borderRadius: "5px", marginTop: "10px" }} onClick={handleGetLocation}>Get Location</button>

                            <GoogleMaps latitude={Number(latitude)} setLatitude={setLatitude} longitude={Number(longitude)} setlongitude={setlongitude}></GoogleMaps>
                        </>
                        :
                        ""}

                    <button style={{ width: "100px", height: "30px", backgroundColor: "#494993", color: "white", border: "none", borderRadius: "5px", marginTop: "10px" }} onClick={handleUpdateProfile}>Save</button>
                    <button style={{ width: "100px", height: "30px", backgroundColor: "crimson", color: "white", border: "none", borderRadius: "5px", marginTop: "10px" }} onClick={handleDeleteProfile}>Delete</button>
                </div>
            </div>

        </div>
    )
}

export default EditProfile