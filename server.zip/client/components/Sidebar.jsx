"use client";
import React, { useEffect } from "react";
import "@styles/patientsidebar.css";
import Link from "next/link";
import { signOut } from "next-auth/react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

const Sidebar = () => {
  const { data: session, status } = useSession();
  // const session = await getServerSession(authOptions)
  const router = useRouter();

  useEffect(() => {
    if (!session) {
      router.push("/login");
    }
  }, [session, router]);

  if (status === "loading") {
    return <div>Loading...</div>;
  }
  return (
    <div className="patientSidebarContainer">
      <div className="logo">
        <h1 style={{color: "white"}}>Telemedicine</h1>
      </div>
      <div className="menuContainer">
        <Link
          href={
            session
              ? session.user.role == "patient"
                ? "/patienthome"
                : session.user.role == "doctor"
                ? "/doctorhome"
                : ""
              : "/patienthome"
          }
        >
          <div className="menu">
            <img src="/icons/icon1.png" alt="" />
            <span>Dashboard</span>
          </div>
        </Link>
        {session && session.user && session.user.role == "patient" ? (
          <Link href={"/alldoctors"}>
            <div className="menu">
              <img src="/icons/icon5.png" alt="" />
              <span>All Doctors</span>
            </div>
          </Link>
        ) : (
          ""
        )}
        {session && session.user && session.user.role == "doctor" ? (
          <Link href={"/appointmentrequests"}>
            <div className="menu">
              <img src="/icons/icon5.png" alt="" />
              <span>Patient Requests</span>
            </div>
          </Link>
        ) : (
          ""
        )}
        {session && session.user && session.user.role == "patient" ? (
          <Link href={"/myappointments"}>
            <div className="menu">
              <img src="/icons/icon2.png" alt="" />
              Appointments
            </div>
          </Link>
        ) : (
          ""
        )}
        {session
              && session.user.role == "patient"
              &&
<Link href={"/prescriptions"}>
          <div className="menu">
            <img src="/icons/icon3.png" alt="" />
            Prescriptions
          </div>
        </Link>
               }
        
        {/* <div className="menu">
          <img src="/icons/icon3.png" alt="" />
          Messages
        </div> */}
        <Link href={"/history"}>
          <div className="menu">
            <img src="/icons/icon4.png" alt="" />
            History
          </div>
        </Link>
        <Link href={"/setting"}>
          <div className="menu">
            <img src="/icons/icon5.png" alt="" />
            <span>Settings</span>
          </div>
        </Link>
        <div
          className="menu"
          onClick={() => {
            signOut();
          }}
        >
          <img src="/icons/icon6.png" alt="" />
          Logout
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
