"use client"
import styles from "@styles/register.module.css"

import React from 'react'

const Security = ({ setSelected, data, setData, setError }) => {

    const handleNext = () => {
        if (data.password.length > 7 && (data.password.match(/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,20}$/))) {
            if (data.password == data.passwordConfirm) {
                setSelected("personalInfo")
            }
            else {
                setError("Password and Confirm Password doesn't match");
                const timeOutId = setTimeout(() => {
                    setError("")
                }, 2000)
                console.log("Timeout Id ", timeOutId);
            }
        }
        else {
            setError("Please enter a strong password");
            const timeOutId = setTimeout(() => {
                setError("")
            }, 2000)
            console.log("Timeout Id ", timeOutId);
        }

    }

    return (
        <div className={`${styles.right}`}>
            <div className={`${styles.logo}`}>
                {/* <img src="/images/logo.png" alt="" /> */}
                <h1>Security</h1>
                <p>Enter a Strong Password</p>
            </div>
            <form autoComplete="off" className={`${styles.inputFieldsContainer}`}>
                <div style={{ display: "flex", flexDirection: "column", justifyContent: "flex-start", gap: "20px", height: "250px", width: "100%" }}>
                    <div className={`${styles.inputFieldsInnerContainer}`}>
                        <label htmlFor="">Password:</label>
                        <input name="password" className={`${styles.inputFields}`} value={data?.password} type="password" onChange={(e) => { setData((prev) => ({ ...prev, [e.target.name]: e.target.value })) }} />
                    </div>
                    <div className={`${styles.inputFieldsInnerContainer}`}>
                        <label htmlFor="">Confirm Password:</label>
                        <input name="passwordConfirm" className={`${styles.inputFields}`} value={data?.passwordConfirm} type="password" onChange={(e) => { setData((prev) => ({ ...prev, [e.target.name]: e.target.value })) }} />
                    </div>
                    <div className={`${styles.inputButtonContainer}`} >
                        <button type="button" className={`${styles.inputButton} ${styles.back}`} onClick={() => setSelected("initialData")}>Back</button>
                        <button type="button" className={`${styles.inputButton}`} onClick={handleNext}>Next</button>
                    </div>
                </div>
            </form>
        </div>
    )
}

export default Security