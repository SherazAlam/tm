import React from 'react'
import styles from "@styles/register.module.css"
import Link from "next/link"


const Confirmation = ({ setSelected, handleSubmit }) => {
    return (
        <div className={`${styles.right}`}>
            <div className={`${styles.confirmContainer}`}>

                <div className={`${styles.textContainer}`}>
                    <div className={`${styles.imageContainer}`}>
                        <img src="/icons/check.svg" alt="" />
                    </div>
                    <h1>Confirmation</h1>
                    <p>Please make sure all the data given are valid!</p>
                </div>

                <div className={`${styles.inputButtonContainerConfirm}`} >
                    <button className={`${styles.inputButton} ${styles.back}`} onClick={() => setSelected("personalInfo")}>Back</button>
                    <button className={`${styles.inputButton}`} onClick={handleSubmit}>Confirm</button>
                </div>

            </div>
        </div >
    )
}

export default Confirmation