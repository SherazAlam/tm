"use client"
import styles from "@styles/register.module.css"

import React from 'react'

const Personal = ({ setSelected, data, setData, setError }) => {

    const handleNext = () => {
        if (data.name == null || data.name == "") {
            setError("Please enter your Name");
            const timeOutId = setTimeout(() => {
                setError("")
            }, 2000)
            console.log("Timeout Id ", timeOutId);
        }
        else if (data.maritalStatus == null || data.maritalStatus == "") {
            setError("Please enter your Marital Status");
            const timeOutId = setTimeout(() => {
                setError("")
            }, 2000)
            console.log("Timeout Id ", timeOutId);
        }
        else if (data.dateOfBirth == null || data.dateOfBirth == "") {
            setError("Please select your Date of Birth");
            const timeOutId = setTimeout(() => {
                setError("")
            }, 2000)
            console.log("Timeout Id ", timeOutId);
        }
        else if (data.bloodGroup == null || data.bloodGroup == "") {
            setError("Please select your Blood Group");
            const timeOutId = setTimeout(() => {
                setError("")
            }, 2000)
            console.log("Timeout Id ", timeOutId);
        }
        else if (data.gender == null || data.gender == "") {
            setError("Please select your Gender");
            const timeOutId = setTimeout(() => {
                setError("")
            }, 2000)
            console.log("Timeout Id ", timeOutId);
        }
        else if (data.role == null || data.role == "") {
            setError("Please select your Role");
            const timeOutId = setTimeout(() => {
                setError("")
            }, 2000)
            console.log("Timeout Id ", timeOutId);
        }
        else {
            setSelected("confirmation")
        }
    }

    return (
        <div className={`${styles.right}`}>
            <div className={`${styles.logo}`}>
                {/* <img src="/images/logo.png" alt="" /> */}
                <h1>Personal Info!</h1>
                <p>Fill in the data to create your account</p>
            </div>
            <form autoComplete="off" className={`${styles.inputFieldsContainerPersonal}`}>
                <div className={`${styles.inputFieldsInnerContainer} ${styles.inputFieldsContainerName}`}>
                    <label htmlFor="">Name:</label>
                    <input name="name" value={data?.name} className={`${styles.inputFields}`} type="text" onChange={(e) => { setData((prev) => ({ ...prev, [e.target.name]: e.target.value })) }} />
                </div>
                <div className={`${styles.inputFieldsInnerContainer}`}>
                    <label htmlFor="">Marital Status:</label>
                    <select name="maritalStatus" value={data?.maritalStatus} className={`${styles.inputFields}`} onChange={(e) => { setData((prev) => ({ ...prev, [e.target.name]: e.target.value })) }}>
                        <option value="" selected>Marital Status</option>

                        <option value="single" >Single</option>
                        <option value="Married">Married</option>
                        <option value="Widowed">Widowed</option>

                    </select>

                </div>
                <div className={`${styles.inputFieldsInnerContainer}`}>
                    <label htmlFor="">Date of Birth:</label>
                    <input name="dateOfBirth" value={data?.dateOfBirth} className={`${styles.inputFields}`} type="date" onChange={(e) => { setData((prev) => ({ ...prev, [e.target.name]: e.target.value })) }} />
                </div>
                <div className={`${styles.inputFieldsInnerContainer}`}>
                    <label htmlFor="">Blood group</label>
                    <select name="bloodGroup" value={data?.bloodGroup} className={`${styles.inputFields}`} type="text" onChange={(e) => { setData((prev) => ({ ...prev, [e.target.name]: e.target.value })) }} >
                        <option value="" selected>Blood Group</option>
                        <option value="A-">A-</option>
                        <option value="A+">A+</option>
                        <option value="AB-">AB-</option>
                        <option value="AB+">AB+</option>
                        <option value="B-">B-</option>
                        <option value="B+">B+</option>
                        <option value="O-">O-</option>
                        <option value="O+">O+</option>
                    </select>
                </div>
                <div className={`${styles.inputFieldsInnerContainer}`}>
                    <label htmlFor="">Gender</label>
                    <select name="gender" value={data?.gender} className={`${styles.inputFields}`} onChange={(e) => { setData((prev) => ({ ...prev, [e.target.name]: e.target.value })) }} >
                        <option value="" selected>Select Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="nonBinary">Non Binary</option>
                    </select>
                </div>
                <div className={`${styles.inputFieldsInnerContainer}`}>
                    <label htmlFor="">Role</label>
                    <select name="role" value={data?.role} className={`${styles.inputFields}`} onChange={(e) => { setData((prev) => ({ ...prev, [e.target.name]: e.target.value })) }} >
                        <option value="" selected>Select Role</option>
                        <option value="doctor">Doctor</option>
                        <option value="patient">Patient</option>

                    </select>

                </div>
                <div className={`${styles.inputButtonContainer}`} >
                    <button type="button" className={`${styles.inputButton} ${styles.back}`} onClick={() => setSelected("security")}>Back</button>
                    <button type="button" className={`${styles.inputButton}`} onClick={handleNext}>Next</button>
                </div>
            </form>
        </div>
    )
}

export default Personal

