const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

const accountSid = "AC1615e06071d83c9a102c42cbbcd22a75";
const authToken = "2301833276d7ec8619dbd2234f150b47";
const client = require("twilio")(accountSid, authToken);
const stripe = require("stripe")(
  "sk_test_51OFrhCA8Z7XYs2EGjaFUuAzXf6KRbeIzIUrAVkW5GeJqUNME4jLpIkrfH3dfPz3S84OMVXixgkgHGPOTR13RixME00ccjVNkbR"
);

async function sendSMS(doctorName) {
  client.messages
    .create({
      body: `Dr. ${doctorName}, has joined the call and waiting for you!.`,
      from: "+13605268324",
      to: "+923465101856",
    })
    .then((message) => console.log(message.sid));
}

app.post("/sendmessage", (req, res) => {
  const { doctorName } = req.body;
  // const { doctorNumber } = req.body;
  // const { patientName } = req.body;
  sendSMS(doctorName);
  res.json({ message: "message sent!" });
});

app.post("/create-checkout-session", async (req, res) => {
  try {
    const data = req.body;
    console.log(data);
    // res.json({ message: "ok" });
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "pkr",
            product_data: {
              name: data.name,
            },
            unit_amount: Number(data.price) * 100,
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `http://localhost:3000/success/{CHECKOUT_SESSION_ID}`,
      cancel_url: `http://localhost:3000/cancel`,
    });
    // cancel_url: `https://app.resumifi.com/cancel?session_id={CHECKOUT_SESSION_ID}`,

    console.log(session);
    res.json({ id: session.id });
  } catch (e) {
    res.json({ message: "Some error occured" });
  }
});
app.post("/get-session-info", async (req, res) => {
  const data = req.body;
  console.log(data);
  try {
    const session = await stripe.checkout.sessions.retrieve(data.sessionId);

    console.log(session);
    res.json({ sessionDetails: session });
  } catch (e) {
    res.json({ message: "Error Occured" });
  }
});

app.listen(process.env.PORT || 8080, function () {
  console.log(
    "Express server listening on port %d in %s mode",
    this.address().port,
    app.settings.env
  );
});
